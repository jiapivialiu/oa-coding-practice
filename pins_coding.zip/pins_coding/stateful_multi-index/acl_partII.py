# 存在层级关系
# world
#└── canada
#    └── vancouver

#Q1: clarifications:
#1. 每个 group 最多只有一个 parent，还是可以有多个 parents？
# 一个已经有 parent 的 group 能否 reparent？or add another parent?
#2. 整体结构保证是 tree/forest，还是一般的 directed graph？
#3. 是否可能出现 cycle？
# group == parent_group 时怎么办？
# 重复添加同一关系是否为 no-op？
# parent_group 必须已经存在吗，还是 add_group 会同时注册两个 group？
#8. hierarchy 是否可以在 permissions 已经存在后继续修改？
#9. 后添加的 hierarchy 是否会 retroactively 改变已有权限？
# 对完全未知的 group 调用 grant/check/revoke 怎么处理？

# part II contract:
# 1. group 和 parent_group 都是单个 nonempty string。
# 2. add_group returns None。
# 3. add_group 会注册 group 和 parent_group；parent_group 不需要预先存在。
# 4. 重复添加完全相同的 child-parent relation 是 no-op。
# 5. 一个 group 已经有 parent 时，可以 reparent；新 parent 覆盖旧 parent。
# 6. group 不能是自己的 parent。
# 7. reparent 后如果产生 cycle，raise ValueError，并且原 hierarchy 不得被修改。
# 8. Hierarchy mutation 立即生效，并 retroactively 改变 inherited access。
# 9. 没有 parent 的 group 是 root 或 standalone group。检查该 group 时，如果没有 direct access，就返回 False。
# 10. 未出现在 hierarchy 中的 group 仍可以 grant/check/revoke，此时只考虑它自己的 direct permission。

#Q2: 现在进入 representation 判断。
# Part I 的 ad_access 是否继续作为 source of truth？yes
# hierarchy 需要保存什么 relationship？tree
# check_access(adv, target_group) 应从 target 往哪个方向寻找？ from child to parent
# 至少比较两种 hierarchy representations。 tree or hashmap
#   hashmap 1: key=child, value=parent
#   hashmap 2: key=parent, value = set of children
#   两个方向都存
# use hashmap 1

# 是扩展现有结构、增加 index，还是完全替换？
# add a hashmap to save parent

#Q3: 给出 add_group、grant、revoke、check 和总 storage 的目标复杂度。
# 定义：
#  G = number of groups
#  M = number of direct permission pairs
#  D = maximum hierarchy depth

# grant_access: expected O(1) time, O(1) incremental space
# revoke_access: expected O(1) time, O(1) auxiliary space
# check_access: expected O(D) time, O(1) auxiliary space
# add_group: expected O(D) time for cycle validation, O(1) auxiliary space

# persistent storage: O(M + G)

from collections import defaultdict
class AccessControl:
    def __init__(self):
        self.ad_access = defaultdict(set)
        self.parent = {}

    def add_group(self, group, parent_group):
        if not isinstance(parent_group, str) or parent_group == "":
            raise ValueError
        if not isinstance(group, str) or group == "":
            raise ValueError

        # cycle validation:
        current = parent_group
        while True:
            if current == group: # parent, or parent's parent == group?
                raise ValueError
            if current not in self.parent:
                break
            current = self.parent[current] # parent's parent

        self.parent[group] = parent_group

    def grant_access(self, advertiser_id, group):
        if not isinstance(advertiser_id, str) or advertiser_id == "":
            raise ValueError
        if not isinstance(group, str) or group == "":
            raise ValueError
        
        self.ad_access[advertiser_id].add(group)

    def revoke_access(self, advertiser_id, group):
        if not isinstance(advertiser_id, str) or advertiser_id == "":
            raise ValueError
        if not isinstance(group, str) or group == "":
            raise ValueError
        
        if advertiser_id in self.ad_access and group in self.ad_access[advertiser_id]:
            self.ad_access[advertiser_id].remove(group)
            if len(self.ad_access[advertiser_id]) == 0:
                del self.ad_access[advertiser_id]

    def check_access(self, advertiser_id, group):
        if not isinstance(advertiser_id, str) or advertiser_id == "":
            raise ValueError
        if not isinstance(group, str) or group == "":
            raise ValueError

        direct_groups = self.ad_access.get(advertiser_id)
        if not direct_groups:
            return False
        
        current = group
        while True:
            if current in direct_groups:
                return True
            if current not in self.parent:
                return False

            current = self.parent[current]


# Q8: Part II tests
# Categories:
# 1. normal hierarchy/inheritance
# 2. empty, invalid, and standalone groups
# 3. duplicate, self-cycle, and longer-cycle boundaries
# 4. sequential permission and hierarchy updates

def assert_raises(expected, function, *args):
    try:
        function(*args)
    except expected:
        return
    except Exception as error:
        raise AssertionError(
            f"Expected {expected}",
            f"Actual {function}"
        )
    else:
        raise AssertionError(
            f"Expected {expected.__name__}, but no exception was raised"
        )

# 1. Normal: an ancestor grant covers itself and descendants, not ancestors.
acl = AccessControl()
assert acl.add_group("canada", "world") is None
assert acl.add_group("vancouver", "canada") is None
acl.grant_access("adv1", "canada")
assert acl.check_access("adv1", "canada") is True
assert acl.check_access("adv1", "vancouver") is True
assert acl.check_access("adv1", "world") is False
assert acl.check_access("unknown_adv", "vancouver") is False

# 2. Standalone/unknown groups use direct permissions only.
acl = AccessControl()
assert acl.check_access("adv1", "standalone") is False
acl.grant_access("adv1", "standalone")
assert acl.check_access("adv1", "standalone") is True
assert acl.check_access("adv1", "other") is False

# Invalid IDs are rejected by every public mutating/query operation.
assert_raises(ValueError, acl.add_group, "", "world")
assert_raises(ValueError, acl.add_group, "canada", "")
assert_raises(ValueError, acl.add_group, None, "world")
assert_raises(ValueError, acl.grant_access, "", "world")
assert_raises(ValueError, acl.revoke_access, "adv1", None)
assert_raises(ValueError, acl.check_access, "adv1", ["world"])

# 3. Duplicate relation is a no-op; self-parenting is rejected.
acl = AccessControl()
acl.add_group("canada", "world")
assert acl.add_group("canada", "world") is None
assert_raises(ValueError, acl.add_group, "world", "world")

# A longer cycle is rejected, and a failed update leaves the old hierarchy intact.
acl.add_group("vancouver", "canada")
acl.grant_access("adv_world", "world")
assert acl.check_access("adv_world", "vancouver") is True
assert_raises(ValueError, acl.add_group, "world", "vancouver")
assert acl.check_access("adv_world", "vancouver") is True

# 4. Reparenting changes inherited access retroactively.
acl = AccessControl()
acl.add_group("canada", "world")
acl.add_group("vancouver", "canada")
acl.grant_access("adv_world", "world")
assert acl.check_access("adv_world", "vancouver") is True

acl.add_group("canada", "north_america")
assert acl.check_access("adv_world", "vancouver") is False
acl.grant_access("adv_na", "north_america")
assert acl.check_access("adv_na", "vancouver") is True

# revoke_access removes only the requested direct grant.
acl.revoke_access("adv_na", "vancouver")  # inherited, so this is a no-op
assert acl.check_access("adv_na", "vancouver") is True
acl.revoke_access("adv_na", "north_america")
assert acl.check_access("adv_na", "north_america") is False
assert acl.check_access("adv_na", "vancouver") is False

# Multiple direct groups remain independent, and duplicate/missing updates are safe.
acl.grant_access("adv2", "world")
acl.grant_access("adv2", "standalone")
acl.grant_access("adv2", "world")
acl.revoke_access("adv2", "world")
assert acl.check_access("adv2", "world") is False
assert acl.check_access("adv2", "standalone") is True
assert acl.revoke_access("missing_adv", "world") is None