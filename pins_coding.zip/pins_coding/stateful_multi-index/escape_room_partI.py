#有 R 个连续房间，编号：0, 1, ..., R-1
#给定一组玩家。游戏开始时，每个玩家都位于 room 0。
#玩家每次调用 advance(player_id)，就向前移动一个房间；通过最后一个房间后，该玩家完成游戏并逃脱。


#1. 你会问哪些 clarification questions？重点考虑：
# what if room_count <= 0? return -1?
# what if duplicated player ids? deduplicate?
# what if a player escaped and still advance? stay in the last room?
# which value to output for advance? Null?
# What happens for an unknown player ID?
# What does get_room return after the player escapes?

# template: 
#Q1. Valid input domain? 输入值
#Q2. Invalid input behavior: exception, sentinel, or ignored? 如果有invalid input怎么办
#Q3. Boundary-state behavior? 边界条件
#Q4. Repeated operation after terminal state? 到终点后怎么办
#Q5. Exact return value of every method? 每个函数的返回值
#Q6. Does the operation mutate state? 操作中会不会改变state


#2. 列出至少三个 candidate representations，例如你认为可能使用的 list/dict/set/class state，但不要默认其中哪个正确。
# i. use deduplicate player ids + unique player_id-room/state hashmap
# ii. use list(list(player ids))
# iii. use room/state-set of player ids hashmap
#选择representation i. 因为使用get_room()时可以快速定位room

#3. 对每种结构说明：
# advance time；
# get_room time: 
# storage；
# ID 是否要求连续；
# invalid player 是否容易处理: yes. 

#4. 选择 representation，并写出：
# source of truth: room_state；
# 两个 invariants: 1. room_state contains exactly one entry for every valid player. 2. Every room_state value is either None or an integer in [0, room_count - 1].
# traversal state 是否存在——如果不存在，也要说明为什么。No. no search across session


#5. 定义变量：
# R = number of rooms
# P = number of players
# 给出 constructor、advance、get_room 的 time/space。
# constructor time O(P), space O(P)
# advance time O(1), space O(1)
# get_room time O(1), space O(1)


#6. 写完整 Python/CoderPad 代码和测试
class EscapeRoom:
    def __init__(self, room_count, player_ids):
        self.room_count = room_count
        if self.room_count <= 0:
            raise ValueError

        if len(set(player_ids)) < len(player_ids):
            raise ValueError
        
        self.room_state = {}
        for player_id in player_ids:
            self.room_state[player_id] = 0

    def advance(self, player_id):
        if player_id not in self.room_state: # never entered
            raise KeyError(player_id)
        
        room = self.room_state[player_id]

        if room is None: # escaped
            return None
        
        if room == self.room_count - 1:
            self.room_state[player_id] = None # set to none
            return None
        
        self.room_state[player_id] += 1
        return room+1

    def get_room(self, player_id):
        if player_id not in self.room_state:
            raise KeyError(player_id)

        return self.room_state[player_id]


# Tests
game = EscapeRoom(
    room_count=3,
    player_ids=["alice", "bob"],
)
assert game.get_room("alice") == 0
game.advance("alice")
assert game.get_room("alice") == 1
game.advance("alice")
assert game.get_room("alice") == 2
#R-1 → None
game.advance("alice")
assert game.get_room("alice") is None
#escaped 后再次 advance
game.advance("alice")

#single-room
game = EscapeRoom(
    room_count=1,
    player_ids=["alice", "bob"],
)
assert game.get_room("alice") == 0
game.advance("alice")
game.advance("alice")
assert game.get_room("alice") is None # do not use `==`
assert game.advance("alice") is None

#Alice/Bob interleaved updates
game = EscapeRoom(
    room_count=3,
    player_ids=["alice", "bob"],
)
game.advance("alice")
game.advance("bob")
assert game.get_room("alice") == 1
assert game.get_room("bob") == 1
game.advance("bob")
assert game.get_room("alice") == 1
game.advance("alice")
assert game.get_room("bob") == 2
game.advance("bob")
assert game.get_room("alice") == 2



# assertion raise test
def assert_raises(expected, function, *args):
    try:
        function(*args)
    except expected:
        return
    except Exception as error:
        raise AssertionError(
            f"Expected {expected}",
            f"Actual {function}"
        )
    else:
        raise AssertionError(
            f"Expected {expected.__name__}, but no exception was raised"

        )

# No rooms
assert_raises(ValueError, EscapeRoom, 0, ["alice"])
assert_raises(ValueError, EscapeRoom, -1, ["alice"])
# Duplicate player
assert_raises(
    ValueError,
    EscapeRoom,
    3,
    ["alice", "alice"],
)
# unknown player
assert_raises(KeyError, game.get_room, "unknown")
assert_raises(KeyError, game.advance, "unknown")

