# Stateful Multi-index

每道状态题都先填：

Source of truth:
Derived indexes:
Update operations:
Query operations:
Invariant:
Most dangerous stale state:

一个状态题通常同时存在两类数据：Source of truth 和 Derived indexes.

## Source of truth *记录现在的真相*

系统真实状态，只应有一份。例如：`player_to_room[player] = room`

## Derived indexes

为了加速特定查询而维护的冗余结构。例如：

```
room_count[room]
room_to_players[room]
```

## Update operations:

更新state的函数

## Query operations:

新增query函数

## Invariant：

`room_count[r]` 必须等于 `player_to_room` 中 `value == r` 的玩家数

## Most dangerous stale state:

## 数据结构选择


| Requirement     | 数据结构                     | 风险                           |
| --------------- | ------------------------ | ---------------------------- |
| ID→当前状态         | dict                     | 通常是 source of truth          |
| membership / 去重 | set                      | 不维护顺序                        |
| FIFO 顺序         | deque                    | 任意删除困难                       |
| 动态 min/max      | heap                     | stale entry，需要 lazy deletion |
| top-K           | heap / ordered structure | 更新与查询存在 trade-off            |
| 层级继承            | parent map               | query 是 O(depth)             |
| 多字段查询           | 多个 inverted indexes      | 更新时必须同步                      |
| 缓存查询结果          | cache                    | invalidation 容易出错            |


