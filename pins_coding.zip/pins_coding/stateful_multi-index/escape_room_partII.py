#请依次回答：

#1. Contract clarification 考虑：
# Invalid room_id 怎么处理？ What happens if room_id is outside [0, room_count - 1]?
# 空房间返回什么？
# 返回 list 还是 set？
# 是否要求固定顺序？
# 返回内部容器还是 defensive copy？
#  调用者拿到返回结果后，能不能意外修改 EscapeRoom 内部保存的状态。---lower risk, more space used
#  只会清空调用者拿到的 copy，不会影响游戏内部状态。
# 代价是：
#  返回方式;	Query time;	Output space;	风险
#  直接返回内部set;	O(1);	O(1);	调用者可以破坏内部状态
#  Defensive copy;	O(K);	O(K);	内部状态安全
#  Immutable result，如 frozenset;	通常 O(K);	O(K);	调用者不能修改
#  其中 K 是该房间的玩家数。因为无论如何都要返回 K 个玩家，所以 O(K) 是合理的 output-sensitive complexity。
# Escaped players 是否出现在任何 room 中？


#2. Representation decision
# Part I 当前只有：player_id -> room / None
# 请比较:
#- 继续只用现有结构，每次扫描；
#- 增加 derived index；
#- 完全替换现有 representation。
# 选择：extend、add index，还是 replace？为什么？

# Select to add a player_state hashmap to save the current room of each player
# Reason: save time in reading players' room

#3. State ownership 
# Source of truth: player_to_room
# Derived index: room_to_players


#4. Invariants
# 至少写三个，特别注意两个结构必须保持同步。

#  Invariant 1: Every player_to_room value is either None or an integer in [0, R-1].
#  Invariant 2: If player_to_room[p] == r, then p appears in room_to_players[r].
#  Invariant 3: Every non-escaped player appears in exactly one room set;
#       every escaped player appears in no room set.
#       第三条很重要，因为仅有 “两个结构包含相同信息” 不够精确。


#5.  State transition
# 对于以下两种情况，列出一次 advance 需要修改哪些 state：
# room r → room r+1
# room R-1 → escaped
# 还要说明更新顺序是否可能让 state 暂时不一致。

# r → r+1:
# - remove player from room_to_players[r]
# - add player to room_to_players[r+1]
# - update player_to_room[player] to r+1
# 
# R-1 → escaped:
# - remove player from room_to_players[R-1]
# - update player_to_room[player] to None


#6. Complexity
# R = number of rooms
# P = number of players
# constructor 只遍历玩家: O(P) in time, O(P) initial persistent space, O(P) temporary space from set(player_ids)
# get_room: O(1) in time, O(1) in space
# advance: O(1) in time and space
# get_players_in_room: O(K) in time, O(K) in space

# Persistent storage after arbitrary updates: O(P) worst case
#   if not delete empty bucket: 长期 storage 有额外的 O(R); 虽然只有一个玩家，但 dict 最终保存了 R 个 room keys 和 R 个 set objects，因为你没有删除空 bucket。
#   if delete, persistent storage is O(P)

# total time: O(P+A+G+sum_j^Q K_j)
# A = number of advance calls
# G = number of get_room calls
# Q = number of get_players_in_room calls
# K_j = 第 j 次 room query 返回的玩家数量

#7. 完整代码:
# get_room(player_id): expected O(1)
# advance(player_id): expected O(1)
# get_players_in_room(room_id): O(K)
# K = number of players returned

from collections import defaultdict
class EscapeRoom:
    def __init__(self, room_count, player_ids):
        self.room_count = room_count
        if self.room_count <= 0:
            raise ValueError

        if len(set(player_ids)) < len(player_ids):
            raise ValueError
        
        self.player_to_room = {}
        for player_id in player_ids:
            self.player_to_room[player_id] = 0
        
        self.room_to_players = defaultdict(set)
        for player_id in player_ids:
            self.room_to_players[0].add(player_id)
        

    def advance(self, player_id):
        if player_id not in self.player_to_room:
            raise KeyError(player_id)
        
        room = self.player_to_room[player_id]

        if room is None:
            return None
        
        if room == self.room_count - 1:
            self.player_to_room[player_id] = None # set to none
            self.room_to_players[room].remove(player_id)
            if not self.room_to_players[room]: # delete empty bucket
                del self.room_to_players[room]
            return None
        
        self.player_to_room[player_id] += 1
        self.room_to_players[room].remove(player_id)
        if not self.room_to_players[room]:
            del self.room_to_players[room]
        self.room_to_players[room+1].add(player_id)
        return room+1

    def get_room(self, player_id):
        if player_id not in self.player_to_room:
            raise KeyError(player_id)

        return self.player_to_room[player_id]

    # 新增高频查询. 不能每次扫描全部 P 个玩家
    def get_players_in_room(self, room_id):
        """
        Return all non-escaped players currently in room_id.
        """
        if room_id >= self.room_count or room_id < 0:
            raise IndexError(room_id)
        
        return self.room_to_players.get(room_id, set()).copy() # `copy` takes O(K) time and space
        



#8. 测试: 
# 初始时所有玩家都在 room 0；
# 玩家移动后从旧 room 消失、在新 room 出现；
# 玩家 escaped 后不属于任何 room；
# empty room；
# interleaved updates；
# 调用者修改返回结果时，不能破坏内部状态。
game = EscapeRoom(
    room_count=3,
    player_ids=["alice", "bob"],
)
game.advance("alice")
game.advance("bob")
assert game.get_room("alice") == 1
assert game.get_room("bob") == 1
assert game.get_players_in_room(1) == set(['alice', 'bob'])

game = EscapeRoom(2, ["alice"])
game.advance("alice")


def assert_raises(expected, function, *args):
    try:
        function(*args)
    except expected:
        return
    except Exception as error:
        raise AssertionError(
            f"Expected {expected}",
            f"Actual {function}"
        )
    else:
        raise AssertionError(
            f"Expected {expected.__name__}, but no exception was raised"

        )

# unknown room id
assert_raises(IndexError, game.get_players_in_room, 4)

# Initial room
game = EscapeRoom(3, ["alice", "bob"])
assert game.get_players_in_room(0) == {"alice", "bob"}

# Empty room
assert game.get_players_in_room(2) == set()

# Escape removes player from every room
game.advance("alice")  # room 1
game.advance("alice")  # room 2
game.advance("alice")  # escaped
assert game.get_room("alice") is None
assert all(
    "alice" not in game.get_players_in_room(room)
    for room in range(3)
)

# Defensive copy
result = game.get_players_in_room(0)
result.clear()
assert game.get_players_in_room(0) == {"bob"}

# Repeated advance after escape
assert game.advance("alice") is None