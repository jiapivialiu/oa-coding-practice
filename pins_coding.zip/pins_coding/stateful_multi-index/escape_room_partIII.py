#请依次回答：

# 现在需要实时显示领先玩家
# 定义：
# 
# “领先”表示处于编号最大的 occupied room。
# 同一个最高房间中的所有玩家都是 leaders。
# Escaped players 不参与。
# 如果所有玩家都 escaped，返回空集合。
# 返回 defensive set，不保证顺序。

# 规模与性能要求：
# P and R may both be very large.
# `get_leaders` is called frequently.
# Neither advance nor get_leaders may scan all P players or all R rooms.

#Q1: clarifications
# what if all rooms are empty? 
# output type? list or set? 
# returned order of leaders? 
# if return defensive copy? copy.
# what if someone has escaped? escaped people are leaders or only players in the rooms considered as leaders? latter one.
# Can players ever move backward? No.
# Can players be added or removed after construction? no 
# How frequent is get_leaders compared with advance? 
#    advance 和 get_leaders 都不能扫描全部 P 或全部 R。

# template:
#    1. What happens when there is no valid result?
#    2. Are ties possible, and do we return all ties?
#    3. Are terminal/inactive entities included?
#    4. What is the output type and ordering?
#    5. Is the returned collection mutable or defensive?
#    6. Which mutations are allowed?
#    7. Which operation is more frequent?

#Q2: representation comparison
# A. 每次 get_leaders 扫描现有 player/room state
# B. 保存一个 cached highest occupied room
# C. 维护能够动态找到最高 occupied room 的额外 index
# choose option C, 维护一个heap of room index. 会保留empty rooms, 在get_leaders时pop出来. 


#最高房间变空时会发生什么: 
#cache/index 何时可能 stale
#expected、amortized 还是 worst-case


#Q3: source of truth、derived indexes、cache/invalidation event 和 invariants

# Source of truth: `player_to_room`
# Existing derived index: `room_to_players`
# New derived candidate index: `leading_room` lazy max-heap

# Invalidation event: A room becomes empty, leaving its heap entry stale.
# Heap invariant: 
#   Every occupied room has at least one heap entry.
#   The heap may additionally contain stale entries (empty room index).
#   After cleanup, the heap top is the highest occupied room.


# Q4: complexity
# P: # players
# R: # rooms
# H = heap entry count, including stale entries
#     H = O(A) worst case, lazy heap
# L = number of returned leaders
#   worst case P
# A = total advance operations; `advance` operations (can be large than room count)
# S = stale entries popped by this call
# U = 其中发生 heap push 的次数, U <= A

#Q: single-operation worst case
# each `advance`: expected O(1) map/set work + O(log H) when a new heap entry is pushed; H = 调用 advance 前 heap 中的 entry 数量
#      因为同一个 room 可以多次 empty → occupied，产生重复 heap entries。heap长度是 H, 不是固定 O(R)。
# each `get_leaders`: O(S log H + L) worst case for one call

#Q: amortized complexity ---因为每个 stale entry 最多被 pop 一次，所以 cleanup 可以做 amortized analysis。
# Persistent storage：O(P + H), players + (may be larger than rooms) heap entries
# space: heap total storage O(H), return output space O(L)---worst case O(P)

# Total advance time: O(A + U log U)
# Worst case: O(A log A), U close to A
# Heap persistent storage: O(U), worst-case O(A)


from collections import defaultdict
class EscapeRoom:
    def __init__(self, room_count, player_ids):
        self.room_count = room_count
        if self.room_count <= 0:
            raise ValueError

        if len(set(player_ids)) < len(player_ids):
            raise ValueError
        
        self.player_to_room = {player_id: 0 for player_id in player_ids}
        
        self.room_to_players = defaultdict(set)
        for player_id in player_ids:
            self.room_to_players[0].add(player_id)

        # discard heap
        #self.leading_room = [0] if player_ids else [] # if room 0 is non-empty
        #heapq.heapify(self.leading_room) # -roomID ascending
        # use doubly linked list containing only non-empty rooms to optimize space
        self.prev_room = {} # previous nonemtpy rooms
        self.next_room = {} # next nonempty rooms
        # if player_ids non-empty:
        if player_ids:
            self.prev_room[0] = None # all players are in room 0 now
            self.next_room[0] = None
            self.head = 0 # start from room 0
            self.tail = 0
        else:
            self.head = None
            self.tail = None

    # insert a new nonempty room in a old nonempty room
    def _insert_room(self, room, new_room):
        nxt = self.next_room[room]
        self.prev_room[new_room] = room
        self.next_room[new_room] = nxt
        self.next_room[room]= new_room
        if nxt is not None:
            self.prev_room[nxt] = new_room
        else:
            self.tail = new_room
    
    def _unlink(self, room):
        # remove an empty room
        prev = self.prev_room[room]
        nxt = self.next_room[room]

        if prev is None:
            self.head = nxt
        else:
            self.next_room[prev] = nxt
        if nxt is None:
            self.tail = prev
        else:
            self.prev_room[nxt] = prev
        del self.prev_room[room]
        del self.next_room[room]

    def advance(self, player_id):
        if player_id not in self.player_to_room:
            raise KeyError(player_id)
        
        room = self.player_to_room[player_id]

        if room is None:
            return None
                
        if room == self.room_count - 1:
            self.player_to_room[player_id] = None # set to none
            self.room_to_players[room].remove(player_id)
            if not self.room_to_players[room]: # delete empty bucket
                del self.room_to_players[room]
                self._unlink(room)
            return None
        
        next_room = room + 1
        if next_room not in self.room_to_players:
            self.room_to_players[next_room] = set()
            self._insert_room(room, next_room)
        self.room_to_players[next_room].add(player_id)
        self.player_to_room[player_id] = next_room

        self.room_to_players[room].remove(player_id)
        if room not in self.room_to_players:
            del self.room_to_players[room]
            self._unlink(room)

        return next_room

    def get_room(self, player_id):
        if player_id not in self.player_to_room:
            raise KeyError(player_id)

        return self.player_to_room[player_id]

    # 新增高频查询. 不能每次扫描全部 P 个玩家
    def get_players_in_room(self, room_id):
        """
        Return all non-escaped players currently in room_id.
        """
        if room_id >= self.room_count or room_id < 0:
            raise IndexError(room_id)
        
        return self.room_to_players.get(room_id, set()).copy() # `copy` takes O(K) time and space
    
    # 现在需要实时显示领先玩家
    def get_leaders(self):
        """
        Return all non-escaped players currently closest to escaping.
        """
        if self.tail is None:
            return set()
        return self.room_to_players[self.tail].copy()


#8. 测试: 
# 初始时所有玩家都在 room 0；
# 玩家移动后从旧 room 消失、在新 room 出现；
# 玩家 escaped 后不属于任何 room；
# empty room；
# interleaved updates；
# 调用者修改返回结果时，不能破坏内部状态。
game = EscapeRoom(
    room_count=3,
    player_ids=["alice", "bob"],
)
game.advance("alice")
game.advance("bob")
assert game.get_room("alice") == 1
assert game.get_room("bob") == 1
assert game.get_players_in_room(1) == set(['alice', 'bob'])

game = EscapeRoom(2, ["alice"])
game.advance("alice")
assert game.get_leaders() == set(['alice'])

def assert_raises(expected, function, *args):
    try:
        function(*args)
    except expected:
        return
    except Exception as error:
        raise AssertionError(
            f"Expected {expected}",
            f"Actual {function}"
        )
    else:
        raise AssertionError(
            f"Expected {expected.__name__}, but no exception was raised"

        )

# unknown room id
assert_raises(IndexError, game.get_players_in_room, 4)

# Initial room
game = EscapeRoom(3, ["alice", "bob"])
assert game.get_players_in_room(0) == {"alice", "bob"}

# Empty room
assert game.get_players_in_room(2) == set()

# Escape removes player from every room
game.advance("alice")  # room 1
game.advance("alice")  # room 2
game.advance("alice")  # escaped
assert game.get_room("alice") is None
assert all(
    "alice" not in game.get_players_in_room(room)
    for room in range(3)
)

# Defensive copy
result = game.get_players_in_room(0)
result.clear()
assert game.get_players_in_room(0) == {"bob"}

# Repeated advance after escape
assert game.advance("alice") is None

# all escaped
game = EscapeRoom(2, ["alice"])
game.advance("alice")  # room 1
game.advance("alice")  # escaped
game.get_leaders()


# No players
game = EscapeRoom(3, [])
assert game.get_leaders() == set()

# “较低房间重新成为 leader”的测试：
game = EscapeRoom(3, ["alice", "bob"])
game.advance("alice")  # alice room 1
game.advance("alice")  # alice room 2
game.advance("bob")    # bob room 1
assert game.get_leaders() == {"alice"}
game.advance("alice")  # alice escaped
assert game.get_leaders() == {"bob"}
