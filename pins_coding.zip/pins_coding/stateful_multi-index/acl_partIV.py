# ACL Part IV — Violation Log
# 
# 在现有 AccessControl 上增加 access-attempt logging。
# 
# 每次 advertiser 尝试访问一个 group 时，系统需要：
# 
# 判断当前是否有权限。
# 返回 True 或 False。
# 如果没有权限，记录一次 violation。

# 先问 clarification questions，重点考虑：
#   时间区间是否包含两端？
#   timestamps 是否保证按顺序到达？
#   同一个时间能否出现多次 violation？
#   返回值结构和顺序是什么？
#   后续 grant、revoke 或 reparent 是否影响历史记录？
#   未知 advertiser/group 的访问是否算 violation？
#   查询复杂度要求是什么？

from bisect import bisect_left, bisect_right
from collections import defaultdict


class AccessControl:
    def __init__(self):
        self.ad_access = defaultdict(set)
        self.group_to_advertisers = defaultdict(set)
        self.parent = {}

        # advertiser_id -> [(timestamp, group), ...]
        self.violations = defaultdict(list)

    # existing methods:
    # add_group
    # grant_access
    # revoke_access
    # check_access
    # get_advertisers_with_access
    @staticmethod
    def _validate_id(value, name):
        if not isinstance(value, str) or value == "":
            raise ValueError(f"{name} must be a nonempty string")

    def add_group(self, group, parent_group):
        self._validate_id(group, "group")
        self._validate_id(parent_group, "parent_group")

        # cycle validation:
        current = parent_group
        while True:
            if current == group:
                raise ValueError
            if current not in self.parent:
                break
            current = self.parent[current]

        self.parent[group] = parent_group

    def grant_access(self, advertiser_id, group):
        self._validate_id(advertiser_id, "advertiser_id")
        self._validate_id(group, "group")
        
        self.ad_access[advertiser_id].add(group)
        self.group_to_advertisers[group].add(advertiser_id)

    def revoke_access(self, advertiser_id, group):
        self._validate_id(advertiser_id, "advertiser_id")
        self._validate_id(group, "group")
        
        if advertiser_id in self.ad_access and group in self.ad_access[advertiser_id]:
            self.ad_access[advertiser_id].discard(group)
            self.group_to_advertisers[group].discard(advertiser_id)
            if len(self.ad_access[advertiser_id]) == 0:
                del self.ad_access[advertiser_id]
            if len(self.group_to_advertisers[group]) == 0:
                del self.group_to_advertisers[group]

    def check_access(self, advertiser_id, group):
        self._validate_id(advertiser_id, "advertiser_id")
        self._validate_id(group, "group")

        direct_groups = self.ad_access.get(advertiser_id)
        if not direct_groups:
            return False
        
        current = group
        while True:
            if current in direct_groups:
                return True
            if current not in self.parent:
                return False

            current = self.parent[current]

    def get_advertisers_with_access(self, group):
        """
        Return a defensive set containing every advertiser
        that currently has direct or inherited access to group.
        """
        self._validate_id(group, "group")

        result = set()
        current = group

        while True:
            result.update(self.group_to_advertisers.get(current, ()))

            if current not in self.parent:
                break
            current = self.parent[current]
    
        return True
    
    def access(self, advertiser_id, group, timestamp):
        self._validate_id(advertiser_id, "advertiser_id")
        self._validate_id(group, "group")

        if not isinstance(timestamp, int) or isinstance(timestamp, bool):
            raise ValueError("timestamp must be an integer")

        allowed = self.check_access(advertiser_id, group)

        if not allowed:
            self.violations[advertiser_id].append((timestamp, group))

        return allowed

    def get_violations(self, advertiser_id, start_time, end_time):
        self._validate_id(advertiser_id, "advertiser_id")

        if (
            not isinstance(start_time, int)
            or isinstance(start_time, bool)
            or not isinstance(end_time, int)
            or isinstance(end_time, bool)
        ):
            raise ValueError("timestamps must be integers")

        if start_time > end_time:
            raise ValueError("start_time cannot exceed end_time")

        records = self.violations.get(advertiser_id, ())

        left = bisect_left(
            records,
            start_time,
            key=lambda record: record[0],
        )
        right = bisect_right(
            records,
            end_time,
            key=lambda record: record[0],
        )

        # Slice creates a defensive copy.
        return list(records[left:right])


# test cases
def assert_raises(expected, function, *args):
    try:
        function(*args)
    except expected:
        return
    except Exception as error:
        raise AssertionError(
            f"Expected {expected.__name__}, got {type(error).__name__}"
        ) from error
    else:
        raise AssertionError(
            f"Expected {expected.__name__}, but no exception was raised"
        )

acl = AccessControl()
acl.add_group("canada", "world")
acl.add_group("vancouver", "canada")
acl.grant_access("ad1", "canada")

assert acl.access("ad1", "vancouver", 100) is True
assert acl.access("ad1", "world", 110) is False
assert acl.access("ad1", "world", 110) is False
assert acl.access("ad2", "canada", 120) is False

assert acl.get_violations("ad1", 0, 200) == [
    (110, "world"),
    (110, "world"),
]

# Both endpoints are included.
assert acl.get_violations("ad1", 110, 110) == [
    (110, "world"),
    (110, "world"),
]

# Later permission changes do not erase historical violations.
acl.grant_access("ad1", "world")
assert acl.access("ad1", "world", 130) is True
assert acl.get_violations("ad1", 0, 200) == [
    (110, "world"),
    (110, "world"),
]

# Defensive copy.
result = acl.get_violations("ad1", 0, 200)
result.clear()
assert len(acl.get_violations("ad1", 0, 200)) == 2

assert acl.get_violations("unknown_ad", 0, 200) == []
assert_raises(ValueError, acl.get_violations, "ad1", 200, 100)
