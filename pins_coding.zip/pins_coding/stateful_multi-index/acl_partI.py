#ACL — Part I
# 实现一个不包含层级继承的 advertiser access-control system
# Part I 中每个 group 都是独立字符串：目前没有 world → country → city 继承关系。

#Q1: Clarification questions：duplicate grant、missing revoke、unknown advertiser/group、返回值、空字符串/None。
# what if grant same ad_id a group that it can already access?
# what to return for grant_access?
# what if a group to revoke has never been granted?
# what if Ad id is empty? 
# Are empty or None group IDs valid?
# is input group one group or a list of multiple groups in each function defined above?
# What should check_access return for an unknown advertiser or group?
# Are groups independent, or does access to "world" imply access to "country" or "city"? ---check hierarchy

# answers:
#    1. Repeated grant is idempotent:
#       Granting an existing permission does not change the state.
#    
#    2. grant_access returns None.
#    
#    3. Revoking a nonexistent permission is a no-op and returns None.
#    
#    4. advertiser_id and group must be nonempty strings.
#       Otherwise raise ValueError.
#    
#    5. Each call receives exactly one group, not a list.
#    
#    6. check_access returns a bool.
#       Unknown advertiser/group returns False.
#    
#    7. Groups are independent in Part I.
#       "world" does not automatically grant access to "country" or "city".

#Q2: 比较至少三种 representation：
# - advertiser 为 key, set of group as values
# - group 为 key, set of advertiser as values
# - (advertiser, group) pair: set of the pairs.
# choose the first one.
#   advertiser → set[groups]:
#   - three operations expected O(1)
#   - efficiently lists all groups of one advertiser
#   
#   group → set[advertisers]:
#   - three operations expected O(1)
#   - efficiently lists all advertisers in one group
#   
#   set[(advertiser, group)]:
#   - three operations expected O(1)
#   - simplest membership representation
#   - listing either side requires scanning all M pairs

#Q3: 选择 representation，说明 
# source of truth: ad_access
# invariants: all key in ad_access are valid advertisers who were granted access to some groups
#    1. Every key maps to a nonempty set of valid groups.
#    2. A permission exists iff group is in ad_access[advertiser_id].
#    3. No permission pair is stored more than once.
#    4. Advertisers with no permissions are absent from ad_access.


#Q4: 给出每个 operation 与 persistent storage 的复杂度。
# M = 当前 active unique permission pairs 数量
# grant: Time O(1) (worst-case O(M) time due to hash collisions), auxiliary space O(1)
# revoke: O(1) time (worst O(M)) and O(1) auxiliary space
# check access: O(1) time (worst O(M)) and O(1) auxiliary space
# total persistent storage: O(M)

from collections import defaultdict
class AccessControl:
    def __init__(self):
        self.ad_access = defaultdict(set)
    
    def grant_access(self, advertiser_id, group):
        if not isinstance(advertiser_id, str) or advertiser_id == "":
            raise ValueError
        if not isinstance(group, str) or group == "":
            raise ValueError
        
        self.ad_access[advertiser_id].add(group)

    def revoke_access(self, advertiser_id, group):
        if not isinstance(advertiser_id, str) or advertiser_id == "":
            raise ValueError
        if not isinstance(group, str) or group == "":
            raise ValueError
        
        if advertiser_id in self.ad_access and group in self.ad_access[advertiser_id]:
            self.ad_access[advertiser_id].remove(group)
            if len(self.ad_access[advertiser_id]) == 0:
                del self.ad_access[advertiser_id]

    def check_access(self, advertiser_id, group):
        if not isinstance(advertiser_id, str) or advertiser_id == "":
            raise ValueError
        if not isinstance(group, str) or group == "":
            raise ValueError

        if advertiser_id not in self.ad_access:
            return False
        if group not in self.ad_access[advertiser_id]:
            return False
        return True


#Q8: normal、idempotent、unknown、sequential grant/revoke tests。
acl = AccessControl()
acl.grant_access("ad1", "canada")
assert acl.check_access("ad1", "canada") is True
assert acl.check_access("ad1", "world") is False
assert acl.check_access("ad2", "world") is False

# duplicate grant
assert acl.grant_access("adv1", "canada") is None
assert acl.grant_access("adv1", "canada") is None  # None, no duplicate state
assert acl.check_access("adv1", "canada") is True   # True
assert acl.check_access("adv1", "usa") is False     # False


def assert_raises(expected, function, *args):
    try:
        function(*args)
    except expected:
        return
    except Exception as error:
        raise AssertionError(
            f"Expected {expected}",
            f"Actual {function}"
        )
    else:
        raise AssertionError(
            f"Expected {expected.__name__}, but no exception was raised"
        )

# empty/None advertiser/group
assert_raises(ValueError, acl.grant_access, "", "usa")   # False
assert_raises(ValueError, acl.check_access, "adv1", "")

# missing advertiser revoke
assert acl.revoke_access("missing_ad", "usa") is None
assert acl.check_access("missing_ad", "usa") is False

assert acl.revoke_access("adv1", "canada") is None  # None
assert acl.revoke_access("adv1", "canada") is None # None, no-op

assert acl.check_access("adv1", "canada") is False  # False

# one advertiser has two groups; revoking one preserves the other
acl.grant_access("ad1", "world")
acl.revoke_access("ad1", "canada")
assert acl.check_access("ad1", "canada") is False
assert acl.check_access("ad1", "world") is True

assert_raises(ValueError, acl.revoke_access, ["adv1"], "usa")

assert_raises(ValueError, acl.grant_access, None, "usa")
assert_raises(ValueError, acl.grant_access, "adv1", ["usa"])
