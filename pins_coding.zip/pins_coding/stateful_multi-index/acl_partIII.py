# 存在层级关系
# world
#└── canada
#    └── vancouver

# Part III: 现在增加反向查询：

from collections import defaultdict


class AccessControl:
    def __init__(self):
        self.ad_access = defaultdict(set)
        self.parent = {}
        self.group_to_advertisers = defaultdict(set)

    @staticmethod
    def _validate_id(value, name):
        if not isinstance(value, str) or value == "":
            raise ValueError(f"{name} must be a nonempty string")

    def add_group(self, group, parent_group):
        self._validate_id(group, "group")
        self._validate_id(parent_group, "parent_group")

        # cycle validation:
        current = parent_group
        while True:
            if current == group:
                raise ValueError
            if current not in self.parent:
                break
            current = self.parent[current]

        self.parent[group] = parent_group

    def grant_access(self, advertiser_id, group):
        self._validate_id(advertiser_id, "advertiser_id")
        self._validate_id(group, "group")
        
        self.ad_access[advertiser_id].add(group)
        self.group_to_advertisers[group].add(advertiser_id)

    def revoke_access(self, advertiser_id, group):
        self._validate_id(advertiser_id, "advertiser_id")
        self._validate_id(group, "group")
        
        if advertiser_id in self.ad_access and group in self.ad_access[advertiser_id]:
            self.ad_access[advertiser_id].discard(group)
            self.group_to_advertisers[group].discard(advertiser_id)
            if len(self.ad_access[advertiser_id]) == 0:
                del self.ad_access[advertiser_id]
            if len(self.group_to_advertisers[group]) == 0:
                del self.group_to_advertisers[group]

    def check_access(self, advertiser_id, group):
        self._validate_id(advertiser_id, "advertiser_id")
        self._validate_id(group, "group")

        direct_groups = self.ad_access.get(advertiser_id)
        if not direct_groups:
            return False
        
        while True:
            if group in direct_groups:
                return True
            if group not in self.parent:
                return False

            group = self.parent[group]

    def get_advertisers_with_access(self, group):
        """
        Return a defensive set containing every advertiser
        that currently has direct or inherited access to group.
        """
        self._validate_id(group, "group")

        result = set()
        current = group

        while True:
            result.update(self.group_to_advertisers.get(current, ())) # set.update() 接受任何 iterable; 拿一个空 iterable，并且不要修改 dictionary
            # update: batch add
            if current not in self.parent:
                break
            current = self.parent[current]

        return result


# Q8: Part II and Part III tests
# Categories:
# 1. normal hierarchy/inheritance
# 2. empty, invalid, and standalone groups
# 3. duplicate, self-cycle, and longer-cycle boundaries
# 4. sequential permission and hierarchy updates

def assert_raises(expected, function, *args):
    try:
        function(*args)
    except expected:
        return
    except Exception as error:
        raise AssertionError(
            f"Expected {expected.__name__}, got {type(error).__name__}"
        ) from error
    else:
        raise AssertionError(
            f"Expected {expected.__name__}, but no exception was raised"
        )

# 1. Normal: an ancestor grant covers itself and descendants, not ancestors.
acl = AccessControl()
assert acl.add_group("canada", "world") is None
assert acl.add_group("vancouver", "canada") is None
acl.grant_access("adv1", "canada")
assert acl.check_access("adv1", "canada") is True
assert acl.check_access("adv1", "vancouver") is True
assert acl.check_access("adv1", "world") is False
assert acl.check_access("unknown_adv", "vancouver") is False

# 2. Standalone/unknown groups use direct permissions only.
acl = AccessControl()
assert acl.check_access("adv1", "standalone") is False
acl.grant_access("adv1", "standalone")
assert acl.check_access("adv1", "standalone") is True
assert acl.check_access("adv1", "other") is False

# Invalid IDs are rejected by every public mutating/query operation.
assert_raises(ValueError, acl.add_group, "", "world")
assert_raises(ValueError, acl.add_group, "canada", "")
assert_raises(ValueError, acl.add_group, None, "world")
assert_raises(ValueError, acl.grant_access, "", "world")
assert_raises(ValueError, acl.revoke_access, "adv1", None)
assert_raises(ValueError, acl.check_access, "adv1", ["world"])

# 3. Duplicate relation is a no-op; self-parenting is rejected.
acl = AccessControl()
acl.add_group("canada", "world")
assert acl.add_group("canada", "world") is None
assert_raises(ValueError, acl.add_group, "world", "world")

# A longer cycle is rejected, and a failed update leaves the old hierarchy intact.
acl.add_group("vancouver", "canada")
acl.grant_access("adv_world", "world")
assert acl.check_access("adv_world", "vancouver") is True
assert_raises(ValueError, acl.add_group, "world", "vancouver")
assert acl.check_access("adv_world", "vancouver") is True

# 4. Reparenting changes inherited access retroactively.
acl = AccessControl()
acl.add_group("canada", "world")
acl.add_group("vancouver", "canada")
acl.grant_access("adv_world", "world")
assert acl.check_access("adv_world", "vancouver") is True

acl.add_group("canada", "north_america")
assert acl.check_access("adv_world", "vancouver") is False
acl.grant_access("adv_na", "north_america")
assert acl.check_access("adv_na", "vancouver") is True

# revoke_access removes only the requested direct grant.
acl.revoke_access("adv_na", "vancouver")  # inherited, so this is a no-op
assert acl.check_access("adv_na", "vancouver") is True
acl.revoke_access("adv_na", "north_america")
assert acl.check_access("adv_na", "north_america") is False
assert acl.check_access("adv_na", "vancouver") is False

# Multiple direct groups remain independent, and duplicate/missing updates are safe.
acl.grant_access("adv2", "world")
acl.grant_access("adv2", "standalone")
acl.grant_access("adv2", "world")
acl.revoke_access("adv2", "world")
assert acl.check_access("adv2", "world") is False
assert acl.check_access("adv2", "standalone") is True
assert acl.revoke_access("missing_adv", "world") is None

# 5. Reverse query returns direct and inherited advertisers.
acl = AccessControl()
acl.add_group("canada", "world")
acl.add_group("vancouver", "canada")
acl.grant_access("ad_world", "world")
acl.grant_access("ad_canada", "canada")
acl.grant_access("ad_vancouver", "vancouver")

assert acl.get_advertisers_with_access("world") == {"ad_world"}
assert acl.get_advertisers_with_access("canada") == {
    "ad_world",
    "ad_canada",
}
assert acl.get_advertisers_with_access("vancouver") == {
    "ad_world",
    "ad_canada",
    "ad_vancouver",
}

# Reverse inheritance goes downward only: a child grant does not cover ancestors.
acl.grant_access("ad_child_only", "vancouver")
assert "ad_child_only" not in acl.get_advertisers_with_access("canada")
assert "ad_child_only" in acl.get_advertisers_with_access("vancouver")

# 6. Empty/standalone queries, validation, and defensive-copy behavior.
assert acl.get_advertisers_with_access("unknown") == set()
acl.grant_access("ad_standalone", "standalone")
assert acl.get_advertisers_with_access("standalone") == {"ad_standalone"}
assert_raises(ValueError, acl.get_advertisers_with_access, "")
assert_raises(ValueError, acl.get_advertisers_with_access, None)
assert_raises(ValueError, acl.get_advertisers_with_access, ["world"])

returned = acl.get_advertisers_with_access("vancouver")
returned.clear()
assert acl.get_advertisers_with_access("vancouver") == {
    "ad_world",
    "ad_canada",
    "ad_vancouver",
    "ad_child_only",
}

# 7. Duplicate grants are idempotent and one revoke removes the direct grant.
acl.grant_access("ad_world", "world")
acl.grant_access("ad_world", "world")
assert acl.get_advertisers_with_access("world") == {"ad_world"}
acl.revoke_access("ad_world", "world")
assert "ad_world" not in acl.get_advertisers_with_access("world")
assert "ad_world" not in acl.get_advertisers_with_access("vancouver")
assert "world" not in acl.ad_access.get("ad_world", set())
assert "ad_world" not in acl.group_to_advertisers.get("world", set())

# Revoking an inherited-but-not-direct permission is a no-op.
acl.revoke_access("ad_canada", "vancouver")
assert "ad_canada" in acl.get_advertisers_with_access("vancouver")

# 8. Reparenting immediately changes reverse-query inheritance.
acl.add_group("canada", "north_america")
acl.grant_access("ad_na", "north_america")
assert "ad_world" not in acl.get_advertisers_with_access("vancouver")
assert "ad_na" in acl.get_advertisers_with_access("vancouver")
assert "ad_canada" in acl.get_advertisers_with_access("vancouver")

# A failed reparent is atomic for both forward and reverse queries.
before = acl.get_advertisers_with_access("vancouver")
assert_raises(ValueError, acl.add_group, "north_america", "vancouver")
assert acl.get_advertisers_with_access("vancouver") == before
assert acl.check_access("ad_na", "vancouver") is True

# 9. Both indexes stay synchronized through multiple direct grants and revokes.
acl.grant_access("ad_multi", "north_america")
acl.grant_access("ad_multi", "standalone")
assert "ad_multi" in acl.group_to_advertisers["north_america"]
assert "ad_multi" in acl.group_to_advertisers["standalone"]
assert acl.ad_access["ad_multi"] == {"north_america", "standalone"}

acl.revoke_access("ad_multi", "north_america")
assert acl.ad_access["ad_multi"] == {"standalone"}
assert "ad_multi" not in acl.group_to_advertisers.get("north_america", set())
assert "ad_multi" in acl.group_to_advertisers["standalone"]

acl.revoke_access("ad_multi", "standalone")
assert "ad_multi" not in acl.ad_access
assert "ad_multi" not in acl.group_to_advertisers.get("standalone", set())

print("All ACL Part III tests passed.")
