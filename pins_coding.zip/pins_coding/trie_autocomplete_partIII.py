# Part III — Stateful Search Session
class TrieNode:
    def __init__(self):
        self.children = {}
        self.is_end = False
        self.count = 0
        
class PinterestAutocomplete:
    def __init__(self):
        self.root = TrieNode()
        self.current_prefix = ""
    
    def input(self, c: str) -> list[str]:
        if not isinstance(c, str) or len(c) != 1:
            raise ValueError
        if c == "#": 
            if self.current_prefix != "": 
                self.add_query(self.current_prefix, 1)
            self.current_prefix = ""
            return []
            
        self.current_prefix += c
        return self.top_k(self.current_prefix, 3)

    def add_query(self, query: str, count: int) -> None:
        if not isinstance(query, str) or query=="":
            return
        if not isinstance(count, int) or isinstance(count, bool) or count <= 0:
            raise ValueError

        node = self.root
        for ch in query: # O(L), L (new nodes) additional persistent space, worst case
            if ch not in node.children:
                node.children[ch] = TrieNode()
            node = node.children[ch]
        node.count += count 
        node.is_end = True

    def top_k(self, prefix: str, k: int) -> list[str]: #time O(P+T+MlogM), space O(M+D+k)
        if not isinstance(prefix, str) or not isinstance(k, int) or isinstance(k, bool):
            raise ValueError
        if k <= 0: return []

        node = self.root
        for ch in prefix: # time O(P), extra space O(1) each time
            if ch not in node.children:
                return []
            node = node.children[ch]

        ans = [] # space O(M)
        def dfs(curr, path): # time O(T). T trie nodes. O(D) space
            if curr.is_end:
                ans.append((path, curr.count))
            for ch, child in curr.children.items(): # curr.children.items() 得到的是 (key, value) pair。
                dfs(child, path+ch) # string coping cost: `path+ch`, O(D) at worst, D: subtree maximum depth
        
        dfs(node, prefix)
        ans.sort(key = lambda x: (-x[1], x[0])) # O(M) temporary space
        return [query for query, _ in ans[:k]] # sorting: O(MlogM) time, O(k) space

engine = PinterestAutocomplete()

engine.add_query("cat", 20)
engine.add_query("cat tree", 50)
engine.add_query("cat furniture", 40)
engine.add_query("dog", 100)

# sequential input
assert engine.input("c") == [
    "cat tree",
    "cat furniture",
    "cat",
]

assert engine.input("a") == [
    "cat tree",
    "cat furniture",
    "cat",
]

# submit existing query
engine.input("t")
assert engine.input("#") == []

# cat: 20 -> 21
assert engine.top_k("cat", 3)[-1] == "cat"

# reset happened
assert engine.current_prefix == ""

# previously nonexistent prefix must NOT mutate Trie
before = len(engine.root.children)
assert engine.top_k("z", 3) == []
assert len(engine.root.children) == before

# empty submission
assert engine.input("#") == []

# invalid
try:
    engine.input("ab")
    assert False
except ValueError:
    pass