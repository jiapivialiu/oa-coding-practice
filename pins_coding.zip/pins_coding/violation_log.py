logs = [
    [1, "rule1", '2022-07-01'], # pin id, rule, date
    [],
]
# `logs` is sorted by date: asc order

#1. given a rule, # unique pins
#2. given a pin id, # unique rules
#3.? given a period, # unique pins
#4.? given a period, # unique rules
#5. given a period, # unique pins per rule --output: hashmap
