# Pinterest Coding：最难 Part 最优解冲刺手册

> 用途：走路时快速复习“需求 → representation → invariant → 最优算法 → 复杂度”。  
> 版本原则：题意来自我们已经讨论过的题目；转述不完整的题会标为 **重建题意**，不能把假设当成面试原题。

## 0. 先纠正一个容易混淆的点

- **Pin–Topic Graph Part III** 的线性解是 `pin -> topics` 与 `topic -> pins` 的隐式二分图加 BFS，**不是 linked list**。
- **Escape Room 的 leaders Part III** 在“玩家只从 `r` 前进到 `r+1`、频繁查询 leaders”这个 contract 下，真正的最优更新结构才是“非空房间的 doubly linked list”；heap 是可行 alternative，但会产生 stale entries，复杂度和空间都更差。
- “最优”必须相对于 operations 与 contract：若需求变化，最优 representation 也可能变化。

## 1. 复杂度统一记号

| 记号 | 含义 |
|---|---|
| `V, E` | 图的节点数、边数 |
| `Q` | query/operation 总数 |
| `N` | 当前题目的输入规模或事件数；每题会重新说明 |
| `K` | 返回结果数或要求的 top-k |
| `H` | 树高 / recursion depth |
| `S` | 原始输入记录数或数值总和；每题会说明 |

复杂度口述模板：

```text
total time = preprocessing + all updates + all queries
space = persistent state + temporary auxiliary space + unavoidable output
```

- Python `dict/set` 读写删：expected `O(1)`，对抗性碰撞的理论 worst case `O(n)`。
- 输出 `K` 个元素本身有 `Ω(K)` 下界；不要把 defensive copy 写成 `O(1)`。
- BFS/DFS 的 `O(V+E)` 指 adjacency-list representation；建图成本必须单独计入。
- 多次 query：不要只报一次 query；应写 `build + Q × per-query`，或更精确地求和。
- amortized `O(1)` 不等于 worst-case `O(1)`；如 dynamic-array append、deque 清理过期事件。

---

# A. 已确认的核心题

## 2. Pin–Topic Graph Part III：避免显式 Pin–Pin clique

### 最难问题

每个 topic 包含若干 Pins；求 `start_pin` 到 `target_pin` 最少经过多少个 topic layer。topic 很大时，不能把同一 topic 内所有 Pins 两两连边。

### 最优 representation 与 invariant

- `topic_to_pins[t]`: topic `t` 的去重 Pin 集合。
- `pin_to_topics[p]`: Pin `p` 所属的 topic 列表。
- BFS queue 中只放 Pin；扩展一个 Pin 时先到 topic，再一次性扩展该 topic 的 Pins。
- `seen_topics` 保证每个 membership edge 最多被扫描一次；一个 BFS level 表示使用一个 topic。

```python
from collections import defaultdict, deque

def min_topic_layers(topics: list[list[str]], start: str, target: str) -> int:
    if start == target:
        return 0

    topic_to_pins: list[set[str]] = []
    pin_to_topics: dict[str, list[int]] = defaultdict(list)

    for topic_id, raw_pins in enumerate(topics):
        pins = set(raw_pins)                 # dedupe within one topic
        topic_to_pins.append(pins)
        for pin in pins:
            pin_to_topics[pin].append(topic_id)

    queue = deque([(start, 0)])
    seen_pins = {start}
    seen_topics: set[int] = set()

    while queue:
        pin, layers = queue.popleft()
        for topic_id in pin_to_topics.get(pin, ()):
            if topic_id in seen_topics:
                continue
            seen_topics.add(topic_id)
            for nxt in topic_to_pins[topic_id]:
                if nxt == target:
                    return layers + 1
                if nxt not in seen_pins:
                    seen_pins.add(nxt)
                    queue.append((nxt, layers + 1))
    return -1
```

令 `R` 为原始 memberships 数（含重复），`M` 为 topic 内去重后的 memberships，`P` 为不同 Pins，`T` 为 topics。

- Build：expected `O(R)` time，`O(P+T+M)` persistent space。
- 一次 BFS：`O(P+T+M)` worst-case time，`O(P+T)` auxiliary space。
- `Q` 个独立 query：`O(R + Q(P+T+M))` worst case；索引只 build 一次。
- 显式 Pin–Pin graph alternative：build `O(R + Σ k_t²)` time/space contribution；BFS 后虽为 `O(P+E)`，但 clique expansion 已经可能平方爆炸。
- DSU alternative：build 约 `O(M α(P))`，connectivity query 约 `O(α(P))`，但**不能**回答 minimum topic layers。
- 有非负 topic cost 时：仍用同一隐式二分图，但 BFS 换 Dijkstra，约 `O((P+T+M) log(P+T))`。

## 3. Escape Room Part III：非空房间 linked list

### 最难问题

玩家只会从房间 `r` 前进到 `r+1`，离开最后一间即 escaped；需要频繁返回最高非空房间中的全部 players，且不能每次扫描所有玩家或房间。

### 最优 representation 与 invariant

- `player_to_room`: source of truth for each player。
- `room_to_players`: 每个非空房间的玩家集合。
- `prev_room/next_room`: 按 room id 排序的**非空房间 doubly linked list**，`tail` 永远是 leader room。
- 因为每次只移动到相邻的 `r+1`，新 destination 节点的位置已知，可 `O(1)` 插入；空 source 可 `O(1)` unlink。

```python
class EscapeRoom:
    def __init__(self, positions: dict[str, int], room_count: int):
        if room_count <= 0:
            raise ValueError("room_count must be positive")
        self.room_count = room_count
        self.player_to_room: dict[str, int | None] = {}
        self.room_to_players: dict[int, set[str]] = {}
        for player, room in positions.items():
            if not 0 <= room < room_count:
                raise ValueError("invalid room")
            self.player_to_room[player] = room
            self.room_to_players.setdefault(room, set()).add(player)

        occupied = sorted(self.room_to_players)
        self.prev_room: dict[int, int | None] = {}
        self.next_room: dict[int, int | None] = {}
        for i, room in enumerate(occupied):
            self.prev_room[room] = occupied[i - 1] if i else None
            self.next_room[room] = occupied[i + 1] if i + 1 < len(occupied) else None
        self.head = occupied[0] if occupied else None
        self.tail = occupied[-1] if occupied else None

    def _unlink(self, room: int) -> tuple[int | None, int | None]:
        left, right = self.prev_room.pop(room), self.next_room.pop(room)
        if left is None:
            self.head = right
        else:
            self.next_room[left] = right
        if right is None:
            self.tail = left
        else:
            self.prev_room[right] = left
        return left, right

    def _insert_between(self, room: int, left: int | None, right: int | None) -> None:
        self.prev_room[room], self.next_room[room] = left, right
        if left is None:
            self.head = room
        else:
            self.next_room[left] = room
        if right is None:
            self.tail = room
        else:
            self.prev_room[right] = room

    def advance(self, player: str) -> None:
        if player not in self.player_to_room or self.player_to_room[player] is None:
            raise ValueError("unknown or escaped player")

        source = self.player_to_room[player]
        source_players = self.room_to_players[source]
        source_players.remove(player)
        source_empty = not source_players

        if source == self.room_count - 1:
            if source_empty:
                self._unlink(source)
                del self.room_to_players[source]
            self.player_to_room[player] = None
            return

        destination = source + 1
        destination_exists = destination in self.room_to_players

        if not destination_exists:
            if source_empty:
                left, right = self._unlink(source)
                del self.room_to_players[source]
            else:
                left, right = source, self.next_room[source]
            self.room_to_players[destination] = set()
            self._insert_between(destination, left, right)
        elif source_empty:
            self._unlink(source)
            del self.room_to_players[source]

        self.room_to_players[destination].add(player)
        self.player_to_room[player] = destination

    def get_leaders(self) -> set[str]:
        if self.tail is None:
            return set()
        return set(self.room_to_players[self.tail])  # defensive copy
```

令 `P` 为玩家数、`O` 为非空房间数、`L` 为 leaders 数、`A` 为 advance 次数。

- 任意初始位置 build：`O(P + O log O)`；若所有人同房开始则 `O(P)`。
- `advance`：expected `O(1)` time，`O(1)` auxiliary space。
- `get_leaders`：`O(L)` time/output space；只返回内部引用才是 `O(1)`，但会破坏封装。
- Persistent space：`O(P+O)`，且 `O ≤ min(P, rooms)`。
- `A` updates + `Q` queries：expected `O(P + O log O + A + ΣL_q)`。
- Lazy max-heap alternative：update `O(log H)` when pushing；query 需清 stale，`O(s log H + L)`；heap 可能随 `A` 增至 `O(A)`。
- Balanced BST alternative：update `O(log O)`、leaders `O(L)`、space `O(P+O)`；适合非相邻任意跳转，但在本 contract 下不如 linked list。

## 4. ACL Part III：atomic reparent + inherited access

### 最难问题

group hierarchy 是 forest；direct grant 可继承。`reparent(child, new_parent)` 若形成 cycle 必须 `raise ValueError`，而且原 hierarchy 完全不变；同时支持检查 advertiser access 和反向查询某 group 的所有 advertisers。

### 最优 update-friendly representation

- `parent[child] = parent`：single source of truth；严格 forest 中每个 child 至多一个 parent。
- 两个一致的 direct-grant indexes：`advertiser_to_groups` 与 `group_to_advertisers`。
- **先沿 `new_parent` 向上做 cycle check，再写 parent**，自然满足 failure atomicity。

```python
from collections import defaultdict

class ACL:
    def __init__(self):
        self.parent: dict[str, str] = {}
        self.advertiser_to_groups: dict[str, set[str]] = defaultdict(set)
        self.group_to_advertisers: dict[str, set[str]] = defaultdict(set)

    def reparent(self, child: str, new_parent: str | None) -> None:
        cur = new_parent                         # validation phase: no mutation
        while cur is not None:
            if cur == child:
                raise ValueError("reparent would create a cycle")
            cur = self.parent.get(cur)

        if new_parent is None:                  # commit phase
            self.parent.pop(child, None)
        else:
            self.parent[child] = new_parent

    def grant(self, advertiser: str, group: str) -> None:
        self.advertiser_to_groups[advertiser].add(group)
        self.group_to_advertisers[group].add(advertiser)

    def revoke(self, advertiser: str, group: str) -> None:
        self.advertiser_to_groups[advertiser].discard(group)
        self.group_to_advertisers[group].discard(advertiser)

    def has_access(self, advertiser: str, group: str) -> bool:
        granted = self.advertiser_to_groups.get(advertiser, ())
        cur = group
        while cur is not None:
            if cur in granted:
                return True
            cur = self.parent.get(cur)
        return False

    def advertisers_with_access(self, group: str) -> set[str]:
        result: set[str] = set()
        cur = group
        while cur is not None:
            result.update(self.group_to_advertisers.get(cur, ()))
            cur = self.parent.get(cur)
        return result
```

令 `D` 为 group 到 root 的深度、`G` 为 groups、`M` 为 direct grants、`K` 为输出 advertisers；并集过程中扫描的 direct grants 数为 `S`。

- `reparent`：`O(D)` time、`O(1)` aux；失败发生在任何 mutation 前。
- `grant/revoke`：expected `O(1)`；`has_access` expected `O(D)`。
- reverse query：expected `O(D+S)` time，`O(K)` output/result space。
- Persistent space：`O(G+M)`。
- Effective-access cache alternative：read 可接近 `O(1)`，但 grant/revoke/reparent 可能使整个 subtree 的 cache invalid，更新 worst case 可到 `Ω(G+M)`；不适合 update-heavy contract。

## 5. Violation Log：append-only temporal range query

### 重建题意

每个 entity 的 violation timestamps 按 nondecreasing 顺序到达；支持 append，以及查询闭区间 `[start, end]` 内的 violations。若原题允许乱序写入，见 alternative。

```python
from bisect import bisect_left, bisect_right
from collections import defaultdict

class ViolationLog:
    def __init__(self):
        self.times: dict[str, list[int]] = defaultdict(list)
        self.payloads: dict[str, list[object]] = defaultdict(list)

    def append(self, entity: str, timestamp: int, payload: object) -> None:
        ts = self.times[entity]
        if ts and timestamp < ts[-1]:
            raise ValueError("timestamps must be nondecreasing per entity")
        ts.append(timestamp)
        self.payloads[entity].append(payload)

    def query(self, entity: str, start: int, end: int) -> list[object]:
        if start > end:
            return []
        ts = self.times.get(entity, ())
        left = bisect_left(ts, start)
        right = bisect_right(ts, end)
        values = self.payloads.get(entity, ())
        return list(values[left:right])
```

令 `N` 为总 logs、`n_e` 为该 entity 的 logs、`K` 为本次输出。

- Append：amortized `O(1)` time；query：`O(log n_e + K)` time。
- Persistent space：`O(N)`；query auxiliary/output：`O(K)`。
- `Q` 个 query：`O(N + Σ(log n_e(q) + K_q))`。
- 乱序 insertion + Python list：查位置 `O(log n_e)` 但移动元素 `O(n_e)`；balanced BST 可做到 `O(log n_e)` insert、`O(log n_e+K)` range query、`O(N)` space。

---
## 6. Sparse Matrix：只乘真正相遇的 nonzeros

### 最难问题

给定 sparse `A (m×k)`、`B (k×n)`，计算 `C=A×B`；representation 必须避免 dense `mkn` 扫描。使用 row maps：`rows[i][j] = nonzero value`。

```python
def sparse_multiply(
    a_rows: list[dict[int, float]],
    b_rows: list[dict[int, float]],
) -> list[dict[int, float]]:
    result: list[dict[int, float]] = []

    for a_row in a_rows:
        out: dict[int, float] = {}
        for inner, a_value in a_row.items():
            for col, b_value in b_rows[inner].items():
                out[col] = out.get(col, 0) + a_value * b_value
        result.append({col: value for col, value in out.items() if value != 0})

    return result
```

令 `zA=nnz(A)`、`zB=nnz(B)`，并定义真实乘法次数

```text
F = Σ over nonzero A[i,p] of nnz(B[p,:]).
```

- 若输入已经是 row maps：multiply time 为 `Θ(F)`；若从 coordinates 建 row maps，总计 expected `Θ(zA+zB+F)`。
- Input representation：`Θ(zA+zB)`；output：`Θ(nnz(C))`。
- 单行 accumulator 临时空间 `O(u_i)`，其中 `u_i` 是该行被触及的不同 output columns，`u_i ≤ min(n,F)`。
- Dense triple-loop alternative：`O(mkn)` time、`O(mn)` dense output space。
- DOK `{(i,j): value}` 最适合 expected `O(1)` point update；CSR 最适合 row scan，但中间插入可能 `O(z)`；representation 要跟 operation 对齐。

## 7. Splitwise / LC465：最少清账 transactions

### 最难问题

先把原始债务压成每个人的 net balance，再返回让全部 balance 归零的**最少 transaction 数**（下面同时保存一份最优 plan）。

```python
from collections import defaultdict

def optimal_settlement(transactions: list[tuple[str, str, int]]):
    net = defaultdict(int)
    for payer, receiver, amount in transactions:
        net[payer] -= amount
        net[receiver] += amount

    people, debt = [], []
    for person, balance in net.items():
        if balance:
            people.append(person)
            debt.append(balance)

    best: list[tuple[str, str, int]] | None = None
    path: list[tuple[str, str, int]] = []
    m = len(debt)

    def dfs(start: int) -> None:
        nonlocal best
        while start < m and debt[start] == 0:
            start += 1
        if start == m:
            if best is None or len(path) < len(best):
                best = path.copy()
            return
        if best is not None and len(path) >= len(best):
            return

        first = debt[start]
        seen_partner_balances = set()
        for j in range(start + 1, m):
            old_partner = debt[j]
            if first * old_partner >= 0 or old_partner in seen_partner_balances:
                continue
            seen_partner_balances.add(old_partner)

            if first < 0:
                payment = (people[start], people[j], -first)
            else:
                payment = (people[j], people[start], first)

            debt[j] = old_partner + first       # fully settle index start
            path.append(payment)
            dfs(start + 1)
            path.pop()
            debt[j] = old_partner

            if old_partner + first == 0:        # exact-cancel symmetry pruning
                break

    dfs(0)
    return best or []
```

令 `T` 为原 transactions、`m` 为 nonzero net balances。

- Balance aggregation：expected `O(T)` time、`O(m)` space。
- Exact DFS：worst-case exponential，常用宽松上界 `O(m!)`；search recursion/path `O(m)`，输出至多 `m-1` 条。
- Duplicate-balance 与 exact-cancel pruning 大幅改善实践性能，但**不改变** worst-case exponential。
- 若只需任意 settlement 而非最少：分别维护 debtors/creditors 双指针，`O(T+m)` expected time、`O(m)` state，输出至多 `m-1` 条；它不保证 transaction count minimum。
- Subset DP alternative：约 `O(3^m)` time、`O(2^m)` space，提供另一种 deterministic exponential trade-off。

## 8. Spam Caller：rolling window reports

### 重建题意

实现 `report(phone, timestamp)` 和最近 `W` 秒内的 report count；所有调用 timestamp 全局 nondecreasing。窗口定义为 `(timestamp-W, timestamp]`。

```python
from collections import defaultdict, deque

class SpamCaller:
    def __init__(self, window: int):
        self.window = window
        self.events = deque()                 # (timestamp, phone)
        self.count_by_phone = defaultdict(int)
        self.last_timestamp = -1

    def _advance(self, timestamp: int) -> None:
        if timestamp < self.last_timestamp:
            raise ValueError("timestamps must be nondecreasing")
        self.last_timestamp = timestamp
        cutoff = timestamp - self.window
        while self.events and self.events[0][0] <= cutoff:
            _, phone = self.events.popleft()
            self.count_by_phone[phone] -= 1
            if self.count_by_phone[phone] == 0:
                del self.count_by_phone[phone]

    def report(self, phone: str, timestamp: int) -> None:
        self._advance(timestamp)
        self.events.append((timestamp, phone))
        self.count_by_phone[phone] += 1

    def count(self, phone: str, timestamp: int) -> int:
        self._advance(timestamp)
        return self.count_by_phone.get(phone, 0)
```

令 `Q` 为总 calls，`A` 为当前窗口内 active reports，`U` 为 active phones。

- 单次 operation worst-case `O(x)`，其中本次清走 `x` 个过期事件；amortized expected `O(1)`。
- 全部 `Q` 次总计 expected `O(Q)`，因为每个 report 只入队、出队各一次。
- Persistent space：`O(A+U)`；temporary `O(1)`。
- 若需查询任意历史区间：不能丢旧事件；改用 `phone -> sorted timestamps`，append amortized `O(1)`，count 用两次 binary search 为 `O(log n_phone)`，space `O(Q)`。
- 若 timestamps 可乱序：deque invariant 失效；需要 ordered multiset/BST，通常 update/query `O(log Q)`。

## 9. Numeric String Rounding：纯字符串进位

### 重建题意

Part I 把 decimal string 四舍五入到整数；hard follow-up 按给定 significant digits 四舍五入，例如保留 3 位：`124900 -> 125000`、`12.49 -> 12.5`。以下采用 half-up（负数按绝对值进位）；banker's rounding 必须另行确认。

```python
def _parse_decimal(text: str):
    negative = text.startswith("-")
    if text[:1] in "+-":
        text = text[1:]
    if text.count(".") > 1:
        raise ValueError("invalid decimal")
    whole, dot, frac = text.partition(".")
    whole = whole or "0"
    if not whole.isdigit() or (dot and frac and not frac.isdigit()):
        raise ValueError("invalid decimal")
    digits = whole + frac
    return negative, digits, len(whole)

def _round_at(digits: str, decimal_index: int, cut: int):
    if cut >= len(digits):
        return digits, decimal_index

    prefix = list(digits[:cut])
    if digits[cut] >= "5":
        i = len(prefix) - 1
        while i >= 0 and prefix[i] == "9":
            prefix[i] = "0"
            i -= 1
        if i >= 0:
            prefix[i] = str(int(prefix[i]) + 1)
        else:
            prefix.insert(0, "1")
            decimal_index += 1
    return "".join(prefix) + "0" * (len(digits) - cut), decimal_index

def _format_decimal(negative: bool, digits: str, decimal_index: int) -> str:
    if decimal_index <= 0:
        whole, frac = "0", "0" * (-decimal_index) + digits
    elif decimal_index >= len(digits):
        whole, frac = digits + "0" * (decimal_index - len(digits)), ""
    else:
        whole, frac = digits[:decimal_index], digits[decimal_index:]
    whole = whole.lstrip("0") or "0"
    frac = frac.rstrip("0")
    answer = whole + (("." + frac) if frac else "")
    return "-" + answer if negative and answer != "0" else answer

def round_to_integer(text: str) -> str:
    negative, digits, decimal_index = _parse_decimal(text)
    digits, decimal_index = _round_at(digits, decimal_index, decimal_index)
    return _format_decimal(negative, digits, decimal_index)

def round_significant(text: str, significant: int) -> str:
    if significant <= 0:
        raise ValueError("significant must be positive")
    negative, digits, decimal_index = _parse_decimal(text)
    first = next((i for i, ch in enumerate(digits) if ch != "0"), None)
    if first is None:
        return "0"
    digits, decimal_index = _round_at(
        digits, decimal_index, first + significant
    )
    return _format_decimal(negative, digits, decimal_index)
```

- 令 `L` 为输入长度：time `Θ(L)`，因为 parse、carry、format 各线性；aux/output `Θ(L)`。
- Carry 最坏穿过全部 retained digits，但仍是 `O(L)`。
- `float` alternative 看似 `O(1)` machine operations，却有 binary floating-point precision、超长输入 overflow/precision loss、tie-rule 不一致；不算可靠 exact-string 解。

## 10. Reconstruct Itinerary / LC332：lexicographically smallest Euler path

### 最难问题

从 `JFK` 出发，每张 ticket 恰好使用一次；在所有合法 itinerary 中返回字典序最小者。关键是 Hierholzer postorder，不是普通 greedy path DFS。

```python
from collections import defaultdict

def find_itinerary(tickets: list[list[str]]) -> list[str]:
    graph: dict[str, list[str]] = defaultdict(list)
    for origin, destination in sorted(tickets, reverse=True):
        graph[origin].append(destination)       # descending per origin

    stack = ["JFK"]
    reverse_route = []
    while stack:
        while graph[stack[-1]]:
            stack.append(graph[stack[-1]].pop())  # smallest destination
        reverse_route.append(stack.pop())

    route = reverse_route[::-1]
    return route if len(route) == len(tickets) + 1 else []
```

令 `E` 为 tickets、`V` 为 airports。

- Sort/build `O(E log E)`；Hierholzer traversal `O(E)`；total `O(E log E)`。
- Persistent/auxiliary adjacency + stack `O(V+E)`；output `O(E)`。
- Duplicate tickets 必须保留为 parallel edges，不能放进 `set`。
- Min-heap per origin alternative：build/traversal worst-case 仍 `O(E log E)`，空间同阶；reverse-sorted list 的 `pop()` 通常常数更小。
- 回溯枚举 itinerary worst-case `O(E!)`；普通 lexicographic greedy 会在 dead end 时错误。

---

# B. 高频算法 follow-ups

## 11. Bus Routes / LC815：route 只展开一次

求 source 到 target 最少乘几辆 bus；`routes[r]` 是 route `r` 经过的 stops。

```python
from collections import defaultdict, deque

def num_buses(routes: list[list[int]], source: int, target: int) -> int:
    if source == target:
        return 0
    stop_to_routes = defaultdict(list)
    for route_id, stops in enumerate(routes):
        for stop in stops:
            stop_to_routes[stop].append(route_id)

    queue = deque([(source, 0)])
    seen_stops, used_routes = {source}, set()
    while queue:
        stop, buses = queue.popleft()
        for route_id in stop_to_routes.get(stop, ()):
            if route_id in used_routes:
                continue
            used_routes.add(route_id)
            for nxt in routes[route_id]:
                if nxt == target:
                    return buses + 1
                if nxt not in seen_stops:
                    seen_stops.add(nxt)
                    queue.append((nxt, buses + 1))
    return -1
```

令 `I=Σ|routes[r]|`、`R` 为 routes、`S` 为 stops：build `O(I)`，query `O(R+S+I)=O(I)`（nonempty routes 时），aux `O(R+S)`，index space `O(S+I)`。显式连接 route 内每对 stops 会变成 `O(Σ|route|²)`。

## 12. Course Schedule：cycle detection + order

`[course, prerequisite]` 表示 `prerequisite -> course`；有 cycle 返回空，否则返回任一拓扑序。

```python
from collections import deque

def course_order(num_courses: int, prerequisites: list[list[int]]) -> list[int]:
    graph = [[] for _ in range(num_courses)]
    indegree = [0] * num_courses
    for course, prerequisite in prerequisites:
        graph[prerequisite].append(course)
        indegree[course] += 1

    queue = deque(i for i, degree in enumerate(indegree) if degree == 0)
    order = []
    while queue:
        node = queue.popleft()
        order.append(node)
        for nxt in graph[node]:
            indegree[nxt] -= 1
            if indegree[nxt] == 0:
                queue.append(nxt)
    return order if len(order) == num_courses else []
```

- Time `O(V+E)`；graph/indegree/queue `O(V+E)`；output `O(V)`。
- Invariant：queue 中是 remaining graph 当前 indegree 为 0 的 nodes；处理不足 `V` 个意味着剩余 directed cycle。
- Three-color DFS alternative 同为 `O(V+E)`，recursion worst `O(V)`；Python 深链可能 stack overflow。
- 与 ACL reparent 的联系：都是 cycle detection；但单次 reparent 在 single-parent forest 中只需沿新 parent 的 ancestor chain 检查，并且必须 validate-before-commit。

## 13. Hiking + K Rest Stops：binary search on answer

给 nonnegative segment times，必须放恰好 `K` 个休息点，即切成 `K+1` 个 nonempty contiguous groups；最小化最大 group sum。

```python
def minimize_longest_climb(times: list[int], k: int) -> int:
    n = len(times)
    if n == 0 or not 0 <= k < n or any(t < 0 for t in times):
        raise ValueError("invalid input")
    groups_allowed = k + 1
    low, high = max(times), sum(times)

    def groups_needed(limit: int) -> int:
        groups, current = 1, 0
        for duration in times:
            if current + duration > limit:
                groups += 1
                current = duration
            else:
                current += duration
        return groups

    while low < high:
        mid = (low + high) // 2
        if groups_needed(mid) <= groups_allowed:
            high = mid
        else:
            low = mid + 1
    return low
```

令 `n=len(times)`、`S=sum(times)`、`M=max(times)`：time `O(n log(S-M+1))`，aux `O(1)`。若需休息点，再线性重建，`O(n)` time、`O(K)` output。`groups_needed≤K+1` 足够，因为 nonnegative 且可在 segment 边界继续拆 group，不会增大最大和。

DP alternative：`dp[g][i]=min_j max(dp[g-1][j], prefix[i]-prefix[j])`，time `O(Kn²)`，space `O(Kn)` 或 rolling `O(n)`；有负数或额外 placement constraints 时，greedy feasibility 可能失效，才需要 DP。

## 14. Shortest Way / LC1055：固定 source、很多 targets

```python
from bisect import bisect_right
from collections import defaultdict

class ShortestWayIndex:
    def __init__(self, source: str):
        self.positions = defaultdict(list)
        for i, ch in enumerate(source):
            self.positions[ch].append(i)

    def query(self, target: str) -> int:
        if not target:
            return 0
        pieces, position = 1, -1
        for ch in target:
            indices = self.positions.get(ch)
            if not indices:
                return -1
            j = bisect_right(indices, position)
            if j == len(indices):
                pieces += 1
                position = indices[0]
            else:
                position = indices[j]
        return pieces
```

令 `S=|source|`、一个 target 长 `L`、全部 queries 总长度 `M`：build `O(S)` time/space；单 query `O(L log S)`、aux `O(1)`；全部 `O(S+M log S)`。固定小 alphabet 的 next-occurrence table 用 `O(S|Σ|)` build/space 换每 query `O(L)`；反复扫描 source worst `O(SL)`。

## 15. Expression Add Operators / LC282：乘法 precedence

```python
def add_operators(num: str, target: int) -> list[str]:
    answers, n = [], len(num)

    def dfs(index: int, total: int, previous: int, expression: str) -> None:
        if index == n:
            if total == target:
                answers.append(expression)
            return
        for end in range(index, n):
            if end > index and num[index] == "0":
                break
            token = num[index:end + 1]
            value = int(token)
            if index == 0:
                dfs(end + 1, value, value, token)
            else:
                dfs(end + 1, total + value, value, expression + "+" + token)
                dfs(end + 1, total - value, -value, expression + "-" + token)
                dfs(end + 1, total - previous + previous * value,
                    previous * value, expression + "*" + token)

    dfs(0, 0, 0, "")
    return answers
```

`previous` 保存最后一个乘法项，使 `a+b*c = (a+b)-b+b*c`。令 digit 数 `n`、答案数 `A`：worst time `O(n·4^n)`（gap 有 concatenate/三运算，字符串也需复制），search stack `O(n)`，output `O(A n)`。先生成再 `eval` 同样 exponential，且增加 parser/security/precedence 风险。

## 16. BST → Sorted Circular Doubly Linked List / LC426

```python
def tree_to_circular_dll(root):
    if root is None:
        return None
    first = last = None

    def inorder(node):
        nonlocal first, last
        if node is None:
            return
        inorder(node.left)
        if last is None:
            first = node
        else:
            last.right, node.left = node, last
        last = node
        inorder(node.right)

    inorder(root)
    first.left, last.right = last, first
    return first
```

Time `O(N)`；recursion aux `O(H)`（balanced `O(log N)`，skewed `O(N)`）；原地复用 nodes，除 recursion 外 output state `O(1)`。Morris traversal 可达 `O(1)` aux，但临时 threading 与原地 pointer 改写更易出错。对已排序 circular DLL 任意插入需先线性找位置 `O(N)`、link `O(1)`；plain linked list 不支持 `O(log N)` positional search。

## 17. Dynamic Autocomplete：Trie node 缓存 top-K

以下最优解假设 frequency 只增加、`K` 是固定小常数；若支持 decrement/delete，见 alternative。

```python
class TrieNode:
    def __init__(self):
        self.children = {}
        self.top = []

class Autocomplete:
    def __init__(self, k: int = 3):
        self.k, self.root, self.frequency = k, TrieNode(), {}

    def _refresh(self, node: TrieNode, sentence: str) -> None:
        candidates = set(node.top)
        candidates.add(sentence)
        node.top = sorted(candidates,
                          key=lambda s: (-self.frequency[s], s))[:self.k]

    def record(self, sentence: str) -> None:
        self.frequency[sentence] = self.frequency.get(sentence, 0) + 1
        node = self.root
        self._refresh(node, sentence)
        for ch in sentence:
            node = node.children.setdefault(ch, TrieNode())
            self._refresh(node, sentence)

    def top_k(self, prefix: str) -> list[str]:
        node = self.root
        for ch in prefix:
            if ch not in node.children:
                return []
            node = node.children[ch]
        return list(node.top)
```

Sentence 长 `L`、prefix 长 `P`、Trie nodes `T`：record `O(LK log K)`，固定 `K` 时 `O(L)`；query `O(P+K)`；space `O(TK + total distinct sentence storage)`。不缓存则 query 需遍历整个 prefix subtree。允许 score decrease/delete 时，cache 可能缺 replacement；需 node 内 ordered set/full candidates 或 lazy heap，更新一般 `O(L log C)`、空间更大。

## 18. Largest Rectangle / LC84：monotonic stack

```python
def largest_rectangle(heights: list[int]) -> int:
    stack, best = [], 0
    for right in range(len(heights) + 1):
        current = 0 if right == len(heights) else heights[right]
        while stack and heights[stack[-1]] > current:
            height = heights[stack.pop()]
            left = stack[-1] if stack else -1
            best = max(best, height * (right - left - 1))
        stack.append(right)
    return best
```

每个 index 至多 push/pop 各一次：time `O(N)`，stack `O(N)`，output `O(1)`。从每根 bar 向两边扩展 `O(N²)`；segment-tree divide-and-conquer 约 `O(N log N)` time、`O(N)` space。

## 19. Is Subsequence：固定大字符串、很多 queries

```python
from bisect import bisect_right
from collections import defaultdict

class SubsequenceIndex:
    def __init__(self, target: str):
        self.positions = defaultdict(list)
        for i, ch in enumerate(target):
            self.positions[ch].append(i)

    def contains(self, source: str) -> bool:
        previous = -1
        for ch in source:
            indices = self.positions.get(ch)
            if not indices:
                return False
            j = bisect_right(indices, previous)
            if j == len(indices):
                return False
            previous = indices[j]
        return True
```

固定 target 长 `n`、全部 query 字符总数 `M`：build `Θ(n)` time/space；单个长度 `m` query `O(m log n)`、`O(1)` aux；全部 `O(n+M log n)`。单 query two-pointer `O(n+m)`；固定小 alphabet 的 next table 用 `O(n|Σ|)` build/space 换 query `O(m)`。

## 20. Ads 放入 K Columns：动态最短列

```python
import heapq

def place_ads(ads: list[int], k: int) -> list[list[int]]:
    if k <= 0:
        raise ValueError("k must be positive")
    columns = [[] for _ in range(k)]
    heap = [(0, column) for column in range(k)]
    heapq.heapify(heap)
    for height in ads:
        total, column = heapq.heappop(heap)
        columns[column].append(height)
        heapq.heappush(heap, (total + height, column))
    return columns
```

`N` ads：time `O(N log K)`；heap aux `O(K)`；完整 placement output `Θ(N+K)`。每次扫描 columns 为 `O(NK)`。特例 `K=2` 直接维护两个 heights 可 `Θ(N)` time、`O(1)` state；不要机械套 heap。

---

# C. 面经转述不完整：先锁定 contract，再套最优结构

## 21. Elevator Dispatch：eligibility + chronological simulation

### Part I：最近可接乘客的 elevator

规则：idle 都可接；moving elevator 只能接“同方向且尚未经过乘客楼层”的人；同层但方向相反也不可接；distance tie 取较小 index。

```python
from dataclasses import dataclass
from enum import Enum

class Direction(Enum):
    UP, DOWN, IDLE = 1, -1, 0

@dataclass
class Elevator:
    floor: int
    direction: Direction

def nearest_elevator(
    elevators: list[Elevator],
    passenger_floor: int,
    passenger_direction: Direction,
) -> int:
    best_index, best_distance = -1, float("inf")
    for index, elevator in enumerate(elevators):
        eligible = elevator.direction == Direction.IDLE or (
            elevator.direction == passenger_direction and (
                elevator.direction == Direction.UP
                and elevator.floor <= passenger_floor
                or elevator.direction == Direction.DOWN
                and elevator.floor >= passenger_floor
            )
        )
        distance = abs(elevator.floor - passenger_floor)
        if eligible and distance < best_distance:
            best_index, best_distance = index, distance
    return best_index
```

`M` elevators：time `O(M)`，aux `O(1)`。若没有额外按 floor/direction 维护的动态 index，必须检查 eligibility，线性扫描是合理基线。

### Hard follow-up：N 个 timestamped requests

原转述缺少 destination、speed、boarding time、route/stop policy、何时转 idle，因此 future state **无法唯一计算**。面试中的最优第一步是指出这些缺口；确定 transition model 后做 event-driven simulation：

```python
def last_assignment(elevators, requests, advance_to, assign):
    # request = (timestamp, floor, direction); sort only if not guaranteed ordered
    requests = sorted(requests, key=lambda request: request[0])  # stable ties
    now, chosen = 0, -1
    for timestamp, floor, direction in requests:
        for elevator in elevators:
            advance_to(elevator, now, timestamp)  # agreed physical/state model
        chosen = nearest_elevator(elevators, floor, direction)
        if chosen != -1:
            assign(elevators[chosen], timestamp, floor, direction)
        now = timestamp
    return chosen
```

- Requests 已排序：`O(NM)` time；未排序：`O(N log N + NM)`。
- State：`O(M)`；若保存 pending stops/requests，则 `O(M+N)`。
- 不能只写“floor += time difference”：idle、到达目标、反向、越过边界时都需要状态 transition。
- 若 contract 允许复杂 routes，用 ordered stop queues；动态 floor indexes 可优化候选搜索，但每部 elevator 的 route mutation 与 eligibility 会增加维护成本。

## 22. ID Assignment `[0,1000)`：resize 后 contiguous repack

### 重建题意

Bucket 有固定顺序和 desired size；每个 bucket 获得连续、不重叠的 IDs。采用 half-open `[start,end)` 消除 `0..999` 与示例端点的 off-by-one 歧义。

```python
class BucketRanges:
    LIMIT = 1000

    def __init__(self, buckets: list[tuple[str, int]]):
        self.order = [name for name, _ in buckets]
        if len(self.order) != len(set(self.order)):
            raise ValueError("duplicate bucket")
        self.sizes = dict(buckets)
        self.ranges: dict[str, tuple[int, int]] = {}
        self._repack()

    def _repack(self) -> None:
        if any(size < 0 for size in self.sizes.values()):
            raise ValueError("negative size")
        if sum(self.sizes.values()) > self.LIMIT:
            raise ValueError("insufficient IDs")
        new_ranges, start = {}, 0
        for name in self.order:
            end = start + self.sizes[name]
            new_ranges[name] = (start, end)
            start = end
        self.ranges = new_ranges                 # atomic commit

    def resize(self, name: str, desired_size: int) -> None:
        if name not in self.sizes:
            raise KeyError(name)
        old = self.sizes[name]
        self.sizes[name] = desired_size
        try:
            self._repack()
        except Exception:
            self.sizes[name] = old
            raise

    def assignments(self) -> list[tuple[str, int, int]]:
        return [(name, *self.ranges[name]) for name in self.order]
```

`B` buckets：build/resize/materialize ranges `O(B)` time，persistent `O(B)`，完整输出 `O(B)`。只重算 resized bucket 后缀可为 `O(B-i)`，但 worst `O(B)`；因为很多后续 ranges 会改变，完整输出有 `Ω(B)` 下界。大量 resize + point ID lookup 可用 Fenwick tree：update/lookup `O(log B)`、space `O(B)`，但输出所有 ranges 仍 `Ω(B)`。

## 23. 比较两个 Nested Sets

### 重建题意

顺序与重复均不重要；元素可为 atom 或 nested set；无 object-reference cycle。用 type-tagged canonical form 避免 `True`/`1` 或 atom/structure 混淆。

```python
def canonical(value):
    if isinstance(value, (list, tuple, set, frozenset)):
        return ("SET", frozenset(canonical(child) for child in value))
    return ("ATOM", type(value).__qualname__, value)

def nested_sets_equal(left, right) -> bool:
    return canonical(left) == canonical(right)
```

令 `N` 为 atoms + membership edges、`H` 为最大嵌套深度：正常 hash 假设下 expected `O(N)` time、`O(N)` canonical state、`O(H)` recursion。Adversarial hash collisions 不保证线性。Deterministic alternative 是对子 canonical forms 排序去重，通常 `O(N log N)` 上界、`O(N)` space。若只是 flat hashable sets，直接 set equality expected `O(n+m)`。

## 24. COVID Spread：先辨认 grid 还是 temporal contacts

### 版本 A：grid 同步传播

所有初始 infected cells 同时向四邻传播；求感染全部 susceptible 的最短时间，不可能则 `-1`。

```python
from collections import deque

def infection_time(grid: list[list[int]]) -> int:
    if not grid or not grid[0]:
        return 0
    rows, cols = len(grid), len(grid[0])
    queue, susceptible = deque(), 0
    for r in range(rows):
        for c in range(cols):
            if grid[r][c] == 2:
                queue.append((r, c, 0))
            elif grid[r][c] == 1:
                susceptible += 1

    answer = 0
    for_pop = ((1, 0), (-1, 0), (0, 1), (0, -1))
    while queue:
        r, c, time = queue.popleft()
        answer = max(answer, time)
        for dr, dc in for_pop:
            nr, nc = r + dr, c + dc
            if 0 <= nr < rows and 0 <= nc < cols and grid[nr][nc] == 1:
                grid[nr][nc] = 2               # mark on enqueue
                susceptible -= 1
                queue.append((nr, nc, time + 1))
    return answer if susceptible == 0 else -1
```

Grid `R×C`：time `Θ(RC)`，queue worst `O(RC)`；原地标记省 visited matrix。对每个感染源分别 BFS 会重复工作，不如 multi-source BFS。

### 版本 B：timestamped contact events

已排序 events 处理 `O(E)`，未排序先 `O(E log E)`；infection-time map `O(V)`。关键澄清：同一 timestamp 是否允许 `A→B→C` 即时链式传播；允许则对该时间批次 contact graph 求 components，不允许则必须基于批次开始前的 snapshot，不能让本批新感染者继续传播。

## 25. Frequency Cap：全局 deque + active counts

窗口 `(timestamp-W,timestamp]`，同一 `(user,pin)` 最多 `limit` 次；timestamps 全局 nondecreasing。

```python
from collections import defaultdict, deque

class FrequencyCap:
    def __init__(self, window: int = 60, limit: int = 3):
        self.window, self.limit = window, limit
        self.events = deque()
        self.counts = defaultdict(int)
        self.last_timestamp = -1

    def _advance(self, timestamp: int) -> None:
        if timestamp < self.last_timestamp:
            raise ValueError("timestamps must be nondecreasing")
        self.last_timestamp = timestamp
        cutoff = timestamp - self.window
        while self.events and self.events[0][0] <= cutoff:
            _, key = self.events.popleft()
            self.counts[key] -= 1
            if self.counts[key] == 0:
                del self.counts[key]

    def can_show(self, user: str, pin: str, timestamp: int) -> bool:
        self._advance(timestamp)
        return self.counts[(user, pin)] < self.limit

    def record(self, user: str, pin: str, timestamp: int) -> None:
        self._advance(timestamp)
        key = (user, pin)
        self.events.append((timestamp, key))
        self.counts[key] += 1
```

`Q` operations、`A` active impressions、`U` active keys：单次 worst `O(x)` expired events，amortized expected `O(1)`；总计 expected `O(Q)`；space `O(A+U)`。`key -> deque` alternative 也有 amortized `O(1)`，但永不再查询的 key 可能永久保留 stale timestamps，space 可达 `O(Q)`。

## 26. Trending Pins：mutable counts + exact top-K

这是一道训练生成的 unseen pattern，不冒充已确认面经。最优结构由 update/query 比例决定。

```python
import heapq
from collections import defaultdict

class TrendingPins:
    def __init__(self):
        self.counts = defaultdict(int)

    def record(self, pin: str) -> None:
        self.counts[pin] += 1

    def top_k(self, k: int) -> list[str]:
        return heapq.nsmallest(
            min(k, len(self.counts)),
            self.counts,
            key=lambda pin: (-self.counts[pin], pin),
        )
```

令 `N` updates、`U` distinct Pins、`K=min(k,U)`、`Q` queries：record expected `O(1)`；query `O(U log max(2,K))`（`K=1` 为 `O(U)`），aux/output `O(K)`；总计 expected `O(N + Σ U_q log max(2,K_q))`，persistent `O(U)`。

Query-heavy alternative：`pin->count` + balanced BST key `(-count,pin)`，update `O(log U)`，top-k `O(K)` after reaching first item，space `O(U)`；Python stdlib 无 balanced BST。Lazy heap update `O(log N)`、query `O((K+stale)log N)`，heap space 可涨到 `O(N)`，不是稳定的最优方案。

---

# D. 走路复习用的最终 checklist

每道题只问自己这 8 句：

1. **Contract**：输入有序吗？允许重复吗？边界是开还是闭？失败是否 atomic？
2. **Operations**：读多还是写多？单次 query 还是很多 queries？要 value、path、count 还是完整 output？
3. **Source of truth**：哪份 state 权威？哪些只是 derived index/cache？
4. **Invariant**：queue/stack/list/tree 中始终保持什么？何时标记 visited？
5. **Build cost**：建反向索引、排序、建图是否已经平方？
6. **Per-operation**：expected、amortized、worst-case 分清；输出 `K` 个至少 `Ω(K)`。
7. **Total**：写成 `build + all updates + Σ query costs`，不要只报单次。
8. **Space**：分 persistent、temporary、recursion、output；lazy deletion 的 stale state 也要算。

### 一眼选结构

| Requirement | 第一候选 | 警告 |
|---|---|---|
| Unweighted minimum layers | BFS | DFS 不保证最短 |
| Nonnegative weighted minimum cost | Dijkstra | 普通 BFS 不够 |
| 只问 connectivity、很多 queries | DSU | 不能还原最短层数 |
| Ordered append + range query | array + binary search | 乱序插入会线性移动 |
| Sliding window + monotonic time | deque + counts | 单次清理是 amortized |
| Dynamic minimum among K items | heap | arbitrary delete/update 不免费 |
| 相邻状态、已知插入位置 | doubly linked list | 任意有序插入仍需搜索 |
| Prefix query | Trie | cache 更新/失效必须算 |
| Graph membership groups | implicit bipartite graph | 不要展开 clique |
| Exact combinatorial minimum | backtracking/DP | 如 LC465，本来就是 exponential |

## 题目状态说明

- **题意较完整、可直接背 invariant**：Pin–Topic、Escape Room、ACL、Sparse Matrix、LC465、String Rounding、LC332、LC815、LC1055、LC282、LC426、LC84、LC392 类多查询。
- **由面经片段重建，面试先澄清**：Violation Log、Spam Caller、Hiking K Rest Stops、Elevator、ID Assignment、Nested Sets、COVID。
- **训练生成 pattern**：Frequency Cap、Trending Pins；用于练 representation 变化，不宣称是已验证的 Pinterest 原题。

> 最后记忆：先说清 `contract + invariant`，再写代码。面试官改变 requirement 时，先判断是 **延伸当前 representation、增加 derived index，还是整体替换**；这比背某段代码更重要。
