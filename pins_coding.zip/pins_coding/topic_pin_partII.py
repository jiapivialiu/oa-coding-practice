# 1. 还需要向面试官确认哪些 contract？
# Q1. “距离”到底数什么？这是最重要的问题：Does one layer mean one shared-topic relationship? 
# In other words, if two different pins share a topic, is their distance 1? Or are we counting topic transfers, in which case it would be 0?
# 两种定义不同：数使用的topics：同一个 topic 中的两个 pins → 1. 数topic transfers：同一个 topic 中的两个 pins → 0
# Q2. 相同 pin or missing pin 
# confirm same pin `pin1 == pin2` and the pin exists, should I return 0? 当前 contract：`min_topic_layers(graph, "p1", "p1") == 0`
# confirm missing pin: `min_topic_layers(graph, "missing", "missing") == -1`
# Q3: Unreachable/missing 的返回值
# What should I return if either pin is missing or they are not connected—-1, None, or infinity?
# missing → -1, unreachable → -1

# Q4: 只返回距离，还是还要返回路径？ [path]
# Do you only need the minimum number of layers, or should I also return the actual sequence of pins or topics?
# only number of topics: BFS + seen
# path: BFS+seen+parent map
# Q5: 是否全部是等权关系？Should every Pin–Pin edge have the same cost? [weighted edges]
# 如果全部 cost 1：BFS
# if topics with varying costs: Dijkstra
# Q6: 一个 query 还是大量 queries？ [multiple queries]
# Is this a single query on a static graph, or should we optimize for many repeated queries?
# 这不改变当前 correctness，但会影响系统设计：
# 单次/少量 query：每次 BFS。
# 大量 query：可能考虑缓存，但需要额外空间及 invalidation。
# 只问 connectivity：可以考虑 DSU。
# 大量 shortest-distance queries：可能预计算，但代价很大。


# 2. 当前 Pin–Pin graph 是否足够？为什么？
# yes, because this graph is designed to have all distance-1 nodes connecting to pin1 from multiple topics saved in one set.

# 3. 比较 DFS、BFS、DSU 三种选择：
# DFS cannot give shortest edges, so use BFS
# Disjoint Set Union，也叫 Union-Find: 判断哪些 nodes 属于同一个 connected component. 它只能回答“能不能连通”，不能回答“最短距离是多少”。

#方法;	Connectivity;	Minimum layers;	适合场景
#DFS	可以;	不能保证首次找到最短;	只判断 reachable
#BFS	可以;	可以，无权图最短距离;	当前要求
#DSU	可以;	不可以返回距离;	大量静态 connectivity queries

# Connectivity only + many queries → DSU
#Unweighted shortest distance     → BFS
#Return actual path               → BFS + parent map
#Weighted shortest distance       → Dijkstra

# 4. 能否保证 minimum layers？
# yes

# 5. 是否需要修改当前 representation？
# no

# 6. 主要 trade-off 是什么？
# Reusing the Pin-Pin graph makes each shortest-distance query straightforward in O(P+E) time.
# However, constructing and storing the clique edges can be expensive:
# build time O(sum L_i + sum K_i^2), graph space O(P+E).


# 7. 你选择的 traversal state 具体表示什么？ (queue、seen、ans 都属于 traversal state; 而是说明每个 object 在搜索过程中的语义和必须始终成立的 invariant)
# The queue stores pins in nondecreasing distance from pin1.
# At each outer-loop iteration, all currently queued pins belong to the same BFS level.
# `seen` contains every discovered pin, so each pin is enqueued once.
# `ans` is the distance of the neighbors discovered in this level.

# 什么是traversal state?
#Data structure: deque、set、dict
#Traversal state: deque/set/dict 里面具体保存什么，以及它代表什么
#: The queue stores the current BFS frontier, and seen stores every discovered pin so each pin is enqueued at most once.
# q: 等待处理的 pins，按照与 pin1 的距离从小到大排列。q 中现有的所有 pins 距离相同。
# seen: 所有已经 discovered 的 pins。 Invariant：每个 pin 最多   一次。queue 中的所有 pins 一定已经在 seen 中。
# ans: 当前正在发现的下一层 neighbors 距离 pin1 多远。
# n: 它也是重要的临时 traversal state：固定当前 BFS level 需要处理的 node 数量。

#完整答案:
# My traversal state consists of a queue, a seen set, and a level counter. 
# The queue stores the current BFS frontier. (BFS frontier 就是当前搜索到的“最外层边界”：已经被发现、但下一步需要展开邻居的 nodes。可以把 BFS 想成水波从起点一圈圈向外扩散)
# The seen set contains every discovered pin, ensuring that each pin is enqueued at most once. 
# At the start of each outer iteration, all nodes currently in the queue are at the same distance, 
# and n = len(queue) preserves that level boundary.


# 8. Time 和 auxiliary-space complexity。
# bfs is O(P+E) time and O(P) space


# 9. 完整可运行代码与测试
from collections import defaultdict, deque
def build_pin_graph(topics):
    """
    Return the Pin-Pin graph.
    """
    pin_pin = defaultdict(set)
    for topic in topics:
        unique_pins = list(set(topic))
        
        e = len(unique_pins)
        for i in range(e):
            pin1 = unique_pins[i]
            pin_pin[pin1] # = pin_pin.get(pin1, set()) # the second part can be dropped
            for j in range(i+1, e): # upper triangle
                pin2 = unique_pins[j]
                pin_pin[pin1].add(pin2)
                pin_pin[pin2].add(pin1)
    return pin_pin
    
def min_topic_layers(graph, pin1, pin2):
    """
    Return the minimum number of Pin-Pin edges needed to reach pin2
    from pin1.

    Same pin: 0
    Directly share a topic: 1
    Unreachable or missing pin: -1
    """
    if pin1 not in graph or pin2 not in graph:
        return -1
    if pin1 == pin2:
        return 0
    
    q = deque()
    q.append(pin1)
    ans = 0
    seen = {pin1} # avoid 同一个 pin 被反复加入 queue; Every pin is enqueued at most once.
    while q:
        n = len(q)
        ans += 1
        for _ in range(n):
            from_pin = q.popleft()
            for to_pin in graph[from_pin]:
                if to_pin == pin2:
                    return ans
                if to_pin not in seen:
                    q.append(to_pin)
                    seen.add(to_pin)
    return -1


topics = [
    ["p1", "p2", "p3"],
    ["p3", "p4"],
    ["p4", "p6"],
    ["p5"],
]

graph = build_pin_graph(topics)

# direct connection
# multi-hop minimum
# same pin
# unreachable
# missing pin
# cycle with a shorter and a longer path
# 连续查询不应修改 graph
assert min_topic_layers(graph, "p1", "p2") == 1
assert min_topic_layers(graph, "p1", "p4") == 2
assert min_topic_layers(graph, "p1", "p6") == 3
assert min_topic_layers(graph, "p1", "p1") == 0
assert min_topic_layers(graph, "p1", "p5") == -1
assert min_topic_layers(graph, "missing", "p1") == -1

#cycle
cycle_graph = build_pin_graph([
    ["a", "b"],
    ["b", "c"],
    ["c", "a"],
    ["z"],
])
assert min_topic_layers(cycle_graph, "a", "z") == -1

# 确认连续查询不修改 graph
before = {
    pin: set(neighbors)
    for pin, neighbors in graph.items()
}
min_topic_layers(graph, "missing", "p1")
min_topic_layers(graph, "p1", "p6")
assert graph == before

# shortest path
shorter_graph = build_pin_graph([
    ["a", "b"],
    ["b", "d"],             # a → b → d，长度 2
    ["a", "c"],
    ["c", "e"],
    ["e", "d"],             # a → c → e → d，长度 3
])
assert min_topic_layers(shorter_graph, "a", "d") == 2