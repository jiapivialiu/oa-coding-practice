# Pinterest Pin–Topic / Pin–Pin Graph 面试复习手册

> 目标：不背单一答案，而是形成稳定的解题链条：  
> **Requirement → Operations → Candidate data structures → Representation → Traversal state → Complexity → Tests**

---

# 0. 最核心理论：先背这一页

## 0.1 复杂度变量

```text
T      = number of topics
L_i    = raw length of topic i，包含重复 pins
K_i    = number of unique pins in topic i
S      = Σ L_i，raw input memberships
M      = Σ K_i，unique Pin–Topic memberships
P      = number of globally unique pins
C      = Σ choose(K_i, 2)，所有 topics 产生的 candidate unordered pin pairs
E      = final number of unique undirected Pin–Pin edges
K_max  = max K_i
```

必须记住：

```text
M ≤ S
E ≤ C
C = Σ K_i(K_i - 1) / 2 = O(Σ K_i²)
无向 adjacency list 保存 2E 个 neighbor entries
```

`C` 与 `E` 不同：

- `C` 把每个 topic 内的 pairs 相加，尚未去除 across-topics 重复。
- `E` 是全部 topics 共同生成的 edges 放入 `set` 后的最终 unique edge 数。

反例：

```python
topics = [
    ["a", "b"],
    ["a", "b"],
    ["a", "b"],
]
```

这里 `C=3`，但 `E=1`。即使 `P` 和 `E` 不变，topic 数增加仍会增加建图时间，因此建图时间不能写成 `O(P+E)`。

## 0.2 各 representation 的复杂度总表

| Representation / operation | Time | Space |
|---|---:|---:|
| Per-topic deduplication | `O(S)` | `O(K_max)` temporary |
| Explicit Pin–Pin graph build | `O(S + ΣK_i²)` | `O(P+E)` output |
| DFS/BFS connectivity on Pin–Pin graph | `O(P+E)` | `O(P)` auxiliary |
| BFS minimum layers on Pin–Pin graph | `O(P+E)` | `O(P)` auxiliary |
| DSU preprocessing | `O(S + M α(P))` | `O(P)` |
| DSU connectivity query | amortized `O(α(P))` | `O(1)` query auxiliary |
| Pin→Topics reverse-index preprocessing | `O(T+S)` | `O(P+M)` additional |
| Implicit bipartite BFS query | `O(P+T+M)` | `O(P+T)` auxiliary |
| Full normalized bipartite storage | — | `O(P+T+M)` |

`α(P)` 是 inverse Ackermann function，实际增长极慢，可近似理解为常数，但面试中应给出正式表达。

## 0.3 为什么 `O(S + ΣK_i²)` 不能随意删除 `S`

只有当 `A=O(B)` 时，才能把 `O(A+B)` 简化为 `O(B)`。

```python
topic = ["a"] * 1_000_000
```

此时：

```text
L_i = 1,000,000
K_i = 1
K_i² = 1
```

仅仅执行 `set(topic)` 就必须读取一百万个 entries，因此不能把 `O(L_i)` 写成 `O(K_i²)=O(1)`。

如果题目保证 topic 内没有重复，则 `L_i=K_i`，而 `K_i≤K_i²`（对非空 topic），这时才能简化为 `O(ΣK_i²)`。

## 0.4 `sum`、`max` 与空间复杂度

如果逐个处理 topics：

```python
for topic in topics:
    unique_pins = list(set(topic))
```

前一个 `unique_pins` 在进入下一个 topic 后可以释放，因此 peak temporary space 是：

```text
O(K_max)，不是 O(ΣK_i)
```

## 0.5 Output space 与 auxiliary space

```text
Pin–Pin graph output space = O(P+E)
BFS auxiliary space        = O(P)
```

BFS 没有复制全部 edges；它只维护 queue 和 seen，因此不能把 BFS auxiliary space 写成 `O(P+E)`。

## 0.6 Graph traversal 的统一复杂度算法

计算 BFS/DFS 复杂度时问两件事：

1. 每个 node 最多被处理几次？
2. 每个 adjacency entry 最多被扫描几次？

有正确 `seen` 时：

```text
每个 node 最多进入 traversal 一次：O(P)
每条无向 edge 从两个端点各扫描一次：O(2E)=O(E)
总 time：O(P+E)
```

## 0.7 Traversal state 与 invariant

Traversal state 不是只列出变量名，而是解释变量在搜索过程中的语义。

```text
queue：已经 discovered、等待展开的 frontier nodes
seen：所有已经 discovered/enqueued 的 nodes
level：当前或下一 frontier 的最短距离
parent：若要求恢复路径，记录首次发现每个 node 的来源
```

最关键 invariant：

```text
Every node is enqueued at most once.
```

所以必须在 **enqueue 时**加入 `seen`，而不是等到 dequeue。

层序 BFS 中：

```python
frontier_size = len(queue)
for _ in range(frontier_size):
    ...
```

`frontier_size` 固定本轮需要处理的 current frontier；本轮新加入的 nodes 属于 next frontier，不会被提前处理。

---

# 1. 45 分钟 Mock Interview 总流程

## 1.1 推荐时间分配

```text
0–3m    Clarify contract and scale
3–7m    Define operations and candidate representations
7–15m   Part I code + tests
15–28m  Part II modification + tests
28–38m  Part III scale change + meaningful code/design
38–43m  Complexity and representation trade-offs
43–45m  Follow-up questions
```

## 1.2 开场必须问的四个方向

### Relationship semantics

```text
Does “related” mean directly sharing a topic, or transitively connected
through multiple topics?
```

### Boundary semantics

```text
If pin1 equals pin2 and the pin exists, should a zero-length path count?
What should happen when a pin is missing?
```

### Input quality

```text
Can a topic contain duplicate pins?
Can topics be empty?
```

### Scale and query pattern

```text
How many topics and memberships can there be?
Is the data static?
Is this one query or many repeated queries?
```

## 1.3 20 秒英文澄清模板

> Before I choose a representation, I’d like to confirm whether “related” means direct or transitive connectivity, whether a zero-length path from an existing pin to itself counts, how missing pins should be handled, and whether duplicates can appear within a topic. I’d also like to know the expected scale and whether we are optimizing for one query or many repeated queries.

---

# 2. Part I：构建 Pin–Pin Graph 并判断 Connectivity

## 2.1 Problem contract

- 每个不同 pin 是一个 node。
- 两个不同 pins 只要共同出现在至少一个 topic 中，就存在无向 edge。
- 不保存 self-edge。
- 不重复保存相同 edge。
- 单 pin topic 仍要保留该 pin node。
- `are_related` 判断 transitive connectivity。
- 已存在的相同 pin 通过 zero-length path 与自己 related。
- missing pin 返回 `False`。

## 2.2 Representation

```python
dict[pin, set[neighbor_pin]]
```

为什么使用 `set`：

- 同一 edge 可能被多个 topics 重复生成。
- `set.add` 平均 `O(1)`。
- 不保存重复 neighbors。

## 2.3 正确建图步骤

对每个 topic：

1. 在 topic 内去重。
2. 先初始化所有 pin keys，以保留 isolated nodes。
3. 只枚举 `i<j` 的 unordered pairs。
4. 双向添加 edge。

## 2.4 Part I 三种算法

### Algorithm A：DFS

适合：只需一次 connectivity 判断。

```text
优点：iterative/recursive 实现直接
缺点：不能保证首次找到的 path 最短；递归版本可能有栈深限制
Time：O(P+E)
Auxiliary space：O(P)
```

### Algorithm B：BFS

适合：connectivity；并且自然扩展到 Part II 的 minimum layers。

```text
优点：无权图中按距离递增访问
缺点：宽 frontier 时 queue 可能较大
Time：O(P+E)
Auxiliary space：O(P)
```

### Algorithm C：DSU / Union-Find

适合：静态数据上大量 connectivity queries，且不需要距离或路径。

```text
优点：query 近似 O(1)，无需构建 topic clique
缺点：不保存 edge/path/distance；删除关系困难
Preprocessing：O(S + M α(P))
Space：O(P)
Query：amortized O(α(P))
```

如果面试官明确要求构建 Pin–Pin graph，应先满足该要求；DSU 作为 alternative/follow-up 讨论。

## 2.5 Part I 完整参考代码

```python
from collections import defaultdict, deque


def unique_in_order(items):
    """Deduplicate while preserving deterministic order."""
    return list(dict.fromkeys(items))


def build_pin_graph(topics):
    """Return dict[pin, set[neighbor_pin]]."""
    graph = defaultdict(set)

    for topic in topics:
        pins = unique_in_order(topic)

        # Preserve isolated nodes from single-pin topics.
        for pin in pins:
            graph[pin]

        # Enumerate each unordered pair exactly once.
        for i in range(len(pins)):
            for j in range(i + 1, len(pins)):
                a, b = pins[i], pins[j]
                graph[a].add(b)
                graph[b].add(a)

    # A normal dict avoids accidental mutation on missing-key queries.
    return {pin: set(neighbors) for pin, neighbors in graph.items()}


def are_related_dfs(graph, pin1, pin2):
    if pin1 not in graph or pin2 not in graph:
        return False

    stack = [pin1]
    seen = {pin1}

    while stack:
        pin = stack.pop()
        if pin == pin2:
            return True

        for neighbor in graph[pin]:
            if neighbor not in seen:
                seen.add(neighbor)
                stack.append(neighbor)

    return False


def are_related_bfs(graph, pin1, pin2):
    if pin1 not in graph or pin2 not in graph:
        return False

    queue = deque([pin1])
    seen = {pin1}

    while queue:
        pin = queue.popleft()
        if pin == pin2:
            return True

        for neighbor in graph[pin]:
            if neighbor not in seen:
                seen.add(neighbor)
                queue.append(neighbor)

    return False
```

## 2.6 DSU 完整参考代码

```python
class DSU:
    def __init__(self):
        self.parent = {}
        self.size = {}

    def add(self, x):
        if x not in self.parent:
            self.parent[x] = x
            self.size[x] = 1

    def find(self, x):
        # Path compression.
        if self.parent[x] != x:
            self.parent[x] = self.find(self.parent[x])
        return self.parent[x]

    def union(self, a, b):
        self.add(a)
        self.add(b)

        root_a = self.find(a)
        root_b = self.find(b)
        if root_a == root_b:
            return

        # Union by size.
        if self.size[root_a] < self.size[root_b]:
            root_a, root_b = root_b, root_a

        self.parent[root_b] = root_a
        self.size[root_a] += self.size[root_b]

    def connected(self, a, b):
        if a not in self.parent or b not in self.parent:
            return False
        return self.find(a) == self.find(b)


def build_pin_dsu(topics):
    dsu = DSU()

    for topic in topics:
        pins = unique_in_order(topic)
        if not pins:
            continue

        first = pins[0]
        dsu.add(first)
        for pin in pins[1:]:
            dsu.union(first, pin)

    return dsu
```

## 2.7 Part I 面试比较题

| Algorithm | Connectivity | Minimum layers | Actual path | Many connectivity queries |
|---|---|---|---|---|
| DFS | Yes | Not by first discovery | With parent | Repeats traversal |
| BFS | Yes | Yes, unweighted graph | With parent | Repeats traversal |
| DSU | Yes | No | No | Best among these three |

标准英文：

> DFS and BFS both answer a single connectivity query in `O(P+E)` time. BFS is the better extension point because Part II asks for an unweighted shortest distance. DSU is attractive for many static connectivity queries, with near-constant amortized query time, but it discards distance and path information.

---

# 3. Part II：Minimum Topic Layers

## 3.1 新 requirement 的澄清问题

最重要的是确认 “distance” 的定义：

```text
如果两个不同 pins 直接共享 topic：
- 数使用的 topics → distance 1
- 数 topic transfers → distance 0
```

建议问：

> Does one layer mean one shared-topic relationship? If two different pins directly share a topic, is their distance one, or are we counting topic transfers? For the same existing pin, should I return zero? Should missing or unreachable pins return negative one? Do you need only the distance or also the actual path?

本手册采用：

```text
same existing pin → 0
direct shared topic → 1
missing/unreachable → -1
```

## 3.2 为什么选择 BFS

Pin–Pin graph 是无权图，每条 edge cost 为 1。BFS 第一次发现一个 node 时得到的就是最短 edge distance。

- Standard DFS first discovery 不保证最短。
- DSU 只知道 connected component，不知道距离。
- Dijkstra 可以做，但在所有 weights 都为 1 时是不必要的额外复杂度。

## 3.3 BFS frontier 与 traversal state

```text
queue：等待处理的 pins，按距离非递减排列
seen：已经 discovered 的 pins
level：本轮新发现 neighbors 的最短距离
frontier_size：当前 BFS level 的 node 数
```

在 outer loop 开始时，queue 中当前已有 nodes 属于同一 frontier。处理本轮过程中，queue 可能暂时同时包含尚未处理的 current-frontier nodes 与刚加入的 next-frontier nodes；`frontier_size` 保证 next frontier 不会被提前处理。

## 3.4 Part II 参考代码

```python
def min_topic_layers(graph, pin1, pin2):
    if pin1 not in graph or pin2 not in graph:
        return -1
    if pin1 == pin2:
        return 0

    queue = deque([pin1])
    seen = {pin1}
    distance = 0

    while queue:
        frontier_size = len(queue)
        next_distance = distance + 1

        for _ in range(frontier_size):
            pin = queue.popleft()

            for neighbor in graph[pin]:
                if neighbor in seen:
                    continue

                seen.add(neighbor)  # Mark when enqueued/discovered.
                if neighbor == pin2:
                    return next_distance
                queue.append(neighbor)

        distance = next_distance

    return -1
```

## 3.5 Part II complexity

```text
Query time：O(P+E)
Auxiliary space：O(P)
```

完整 pipeline（建 Pin–Pin graph + 一个 BFS query）：

```text
Time：O(S + ΣK_i² + P + E)
     = O(S + ΣK_i²)

Space excluding given input：O(P+E)
```

这里 `P≤S`，并且 `E≤C≤O(ΣK_i²)`，所以 BFS 项可以被建图上界吸收。但面试中仍应先分别报告 preprocessing 与 query，而不是只给合并结果。

---

# 4. Part III：大规模数据，不允许显式 clique

## 4.1 Scale change

```text
T up to 100,000 topics
M up to 1,000,000 unique Pin–Topic memberships
One topic may contain 100,000 pins
```

一个包含 100,000 pins 的 topic 会产生约五十亿个 unordered Pin–Pin pairs，因此 Part I representation 无法扩展。

## 4.2 Requirement → required operations

从一个 pin 扩展时需要：

```text
pin → containing topics
```

从一个 topic 扩展时需要：

```text
topic → contained pins
```

因此必须能够沿着：

```text
pin → topic → pin
```

进行搜索，而不物化所有 Pin–Pin pairs。

## 4.3 Candidate representation A：原始 topics + reverse index（推荐）

```python
topic_to_pins[topic_id]   # 原始或 normalized topics
pin_to_topics[pin]        # 新增 reverse index
```

这是 **add an index**：保留原始 `topic→pins`，添加缺失的 `pin→topics`。

优点：

- 与 memberships 近似线性。
- queue 只放 pins。
- 一个 nested expansion `pin→topic→pin` 正好代表一个 logical topic layer。
- 代码与内存常数较小。

## 4.4 Candidate representation B：统一显式 bipartite adjacency graph

```python
adj[("pin", pin_id)]     -> topic nodes
adj[("topic", topic_id)] -> pin nodes
```

优点：标准、通用、容易给两种 node types 添加统一 graph operations。

缺点：

- queue 需要 typed nodes。
- 一个 logical layer 对应两条 bipartite edges。
- 实现与常数开销更大。

两者的渐近复杂度相同；区别是隐式 two-index 表达与统一显式 graph 表达。

## 4.5 被拒绝的 alternatives

### Explicit Pin–Pin graph

被 `O(ΣK_i²)` build time 与潜在 quadratic space 淘汰。

### DSU

可以在线性附近完成 connectivity preprocessing，但不能返回 minimum layers。

### 每次从 pin 扫描全部 topics

不建立 reverse index 时，从一个 pin 找 containing topics 需要扫描全部输入；在 BFS 中重复执行会非常昂贵。

## 4.6 Part III traversal state

```text
queue entry：一个 pin
seen_pins：已经 discovered/enqueued 的 pins
seen_topics：已经展开过的 topics
level：minimum logical topic-layer distance
```

Invariants：

```text
At the beginning of each outer BFS iteration, all pins currently in
the queue have the same minimum topic-layer distance.

Expanding a pin at distance d through an unseen topic discovers pins
at distance d+1.

Each pin is enqueued at most once.
Each topic is expanded at most once.
```

`seen_topics` 非常关键：如果一个大 topic 从其中每个 pin 被重复展开，query 又会退化为接近 clique work。

## 4.7 Part III 完整参考代码

```python
class PinTopicIndex:
    def __init__(self, topics):
        self.topic_to_pins = []
        self.pin_to_topics = defaultdict(list)

        for topic_id, raw_topic in enumerate(topics):
            pins = unique_in_order(raw_topic)
            self.topic_to_pins.append(pins)

            for pin in pins:
                self.pin_to_topics[pin].append(topic_id)

    def min_layers(self, pin1, pin2):
        if pin1 not in self.pin_to_topics or pin2 not in self.pin_to_topics:
            return -1
        if pin1 == pin2:
            return 0

        queue = deque([pin1])
        seen_pins = {pin1}
        seen_topics = set()
        distance = 0

        while queue:
            frontier_size = len(queue)
            next_distance = distance + 1

            for _ in range(frontier_size):
                pin = queue.popleft()

                for topic_id in self.pin_to_topics[pin]:
                    if topic_id in seen_topics:
                        continue
                    seen_topics.add(topic_id)

                    for neighbor in self.topic_to_pins[topic_id]:
                        if neighbor in seen_pins:
                            continue

                        seen_pins.add(neighbor)
                        if neighbor == pin2:
                            return next_distance
                        queue.append(neighbor)

            distance = next_distance

        return -1
```

## 4.8 Part III complexity

代码将 raw topics normalized 后存储：

```text
Preprocessing time：O(T+S)
Stored representation：O(P+T+M)
Worst-case query time：O(P+T+M)
Query auxiliary space：O(P+T)
```

如果输入保证 topics 内没有重复，`S=M`，preprocessing 可写成 `O(T+M)`。

如果有 `Q` 次 query：

```text
O(T+S) preprocessing
+ Q · O(P+T+M) worst-case query time
```

不要在每次 query 内重新建立 reverse index。

---

# 5. 完整测试清单

## 5.1 必须覆盖的类别

```text
normal direct connection
multi-hop connection
same existing pin
missing pin
unreachable component
empty topics input
single-pin topic
duplicate pin inside a topic
repeated edge across topics
cycle with unreachable target
shorter and longer competing paths
sequential queries do not mutate the representation
one very large topic
```

## 5.2 可运行测试

```python
def run_tests():
    topics = [
        ["p1", "p2", "p3"],
        ["p3", "p4"],
        ["p4", "p6"],
        ["p5"],
    ]

    graph = build_pin_graph(topics)

    # Part I: DFS and BFS connectivity.
    for related in (are_related_dfs, are_related_bfs):
        assert related(graph, "p1", "p4") is True
        assert related(graph, "p1", "p5") is False
        assert related(graph, "p1", "p1") is True
        assert related(graph, "missing", "missing") is False

    # Isolated pin and no self-edge.
    single_graph = build_pin_graph([["solo"]])
    assert single_graph == {"solo": set()}

    # Duplicate pin and repeated edge across topics.
    duplicate_graph = build_pin_graph([
        ["a", "a", "b"],
        ["a", "b"],
    ])
    assert duplicate_graph == {"a": {"b"}, "b": {"a"}}

    # Empty input.
    assert build_pin_graph([]) == {}

    # Cycle with unreachable target.
    cycle_graph = build_pin_graph([
        ["a", "b"],
        ["b", "c"],
        ["c", "a"],
        ["z"],
    ])
    assert are_related_bfs(cycle_graph, "a", "z") is False

    # Part II distances.
    assert min_topic_layers(graph, "p1", "p2") == 1
    assert min_topic_layers(graph, "p1", "p4") == 2
    assert min_topic_layers(graph, "p1", "p6") == 3
    assert min_topic_layers(graph, "p1", "p1") == 0
    assert min_topic_layers(graph, "p1", "p5") == -1

    # Short and long competing paths.
    competing = build_pin_graph([
        ["a", "b"],
        ["b", "d"],          # a-b-d: length 2
        ["a", "c"],
        ["c", "e"],
        ["e", "d"],          # a-c-e-d: length 3
    ])
    assert min_topic_layers(competing, "a", "d") == 2

    # Sequential queries must not mutate the graph.
    before = {pin: set(neighbors) for pin, neighbors in graph.items()}
    min_topic_layers(graph, "missing", "p1")
    min_topic_layers(graph, "p1", "p6")
    assert graph == before

    # DSU connectivity.
    dsu = build_pin_dsu(topics)
    assert dsu.connected("p1", "p6") is True
    assert dsu.connected("p1", "p5") is False

    # Part III implicit bipartite representation.
    index = PinTopicIndex(topics)
    assert index.min_layers("p1", "p2") == 1
    assert index.min_layers("p1", "p4") == 2
    assert index.min_layers("p1", "p6") == 3
    assert index.min_layers("p1", "p1") == 0
    assert index.min_layers("p1", "p5") == -1

    duplicate_index = PinTopicIndex([["a", "a", "b"], ["b", "c"]])
    assert duplicate_index.min_layers("a", "c") == 2

    large_index = PinTopicIndex([[f"p{i}" for i in range(10_000)]])
    assert large_index.min_layers("p1", "p9999") == 1


if __name__ == "__main__":
    run_tests()
    print("All Pin graph tests passed.")
```

---

# 6. Mock Interview 问题库

## 6.1 Contract clarification

1. “Related” 是 direct 还是 transitive？
2. 同一个已存在 pin 是否返回 `True` / distance `0`？
3. Missing pin 返回什么？
4. Topic 内能否出现 duplicate pins？
5. Empty topic 或 single-pin topic 是否允许？
6. Graph 是 undirected 吗？
7. “Layers” 数 topics used 还是 topic transfers？
8. 只返回 distance，还是还要 path/topic sequence？
9. 一个 query 还是大量 repeated queries？
10. Topics 是否会动态增加、删除或更新？

## 6.2 Representation questions

1. 为什么 `dict[pin, set[pin]]` 比 `dict[pin, list[pin]]` 更合适？
2. 为什么单 pin topic 必须显式初始化 key？
3. 为什么不能通过添加 self-edge 保存 isolated node？
4. 为什么只枚举 `i<j`？
5. Explicit Pin–Pin graph 的 worst case 是什么？
6. `C` 和 `E` 有什么区别？
7. 为什么 Part III 需要 reverse index？
8. “Add an index” 与 “replace representation” 有什么区别？
9. 隐式 two-index bipartite graph 与统一显式 bipartite adjacency 有何区别？
10. 什么情况下 DSU 比 graph traversal 更合适？

## 6.3 Traversal questions

1. DFS 和 BFS 在 Part I 是否都正确？
2. 为什么 BFS 能保证 minimum layers？
3. `seen` 为什么必须在 enqueue 时更新？
4. BFS frontier 是什么？
5. `frontier_size=len(queue)` 为什么重要？
6. 没有 `seen` 时会发生什么？
7. Part III 为什么同时需要 `seen_pins` 和 `seen_topics`？
8. Part III queue 为什么只存 pin，而不存 topic？
9. 如果要返回 actual path，需要增加什么 state？
10. 如果 edge 加权，哪些 state 和 data structure 会变化？

## 6.4 Complexity questions

1. 为什么建 Pin–Pin graph 不是 `O(P)`？
2. 为什么 `E` 不能吸收 across-topics 的重复 candidate work？
3. 为什么 deduplication 需要 `O(S)`？
4. 为什么 temporary dedup space 是 `O(K_max)`，不是 `O(M)`？
5. 为什么 BFS auxiliary space 是 `O(P)`？
6. 为什么无向 graph 扫描 `2E` entries 仍写作 `O(E)`？
7. Part III preprocessing 与 query 为什么应该分别报告？
8. 多次 queries 时，总复杂度怎么写？

## 6.5 标准 complexity 英文回答

> Let `L_i` be the raw size and `K_i` the number of unique pins in topic `i`. Deduplicating the input takes `O(sum L_i)` time. Building the explicit Pin–Pin graph takes `O(sum L_i + sum K_i squared)` time because every topic creates a clique. The resulting graph uses `O(P+E)` space. A BFS query takes `O(P+E)` time and `O(P)` auxiliary space.

> At large scale, I would keep the original topic-to-pins lists and add a reverse pin-to-topics index. This represents the bipartite graph in `O(P+T+M)` storage. Each pin and topic is processed at most once and each membership is scanned a constant number of times, so a worst-case query takes `O(P+T+M)` time with `O(P+T)` auxiliary space.

---

# 7. 高频错误清单

写完代码后逐项检查：

```text
[ ] defaultdict 的 factory 写作 defaultdict(set)，不是 defaultdict(value=set)
[ ] 没有混用 tabs 和 spaces
[ ] Topic 内先去重
[ ] Isolated pin 成为 key，但没有 self-edge
[ ] 只枚举 unordered pairs i<j
[ ] 无向 edge 双向添加
[ ] Missing-key query 不会意外修改 graph
[ ] Same existing pin 的 zero-length path 按 contract 处理
[ ] BFS/DFS 有 seen
[ ] Node 在 enqueue/push 时加入 seen
[ ] Neighbor 被真正加入 queue/stack
[ ] Recursive DFS 正确 return recursive result
[ ] BFS level boundary 使用原始 frontier_size
[ ] Part III 同时维护 seen_pins 和 seen_topics
[ ] Preprocessing 不在每个 query 中重复执行
[ ] Time complexity 区分 raw input、candidate work 和 final output
[ ] Space complexity 区分 output 与 auxiliary
[ ] Tests 覆盖 empty/single/duplicate/cycle/unreachable/sequential calls
```

---

# 8. 发散 Follow-ups（最后复习）

## 8.1 Weighted topics：Dijkstra follow-up

### 可能的面试题

现在每个 topic 有一个非负 cost：

```python
topics = [
    ["p1", "p2", "p3"],
    ["p3", "p4"],
    ["p4", "p6"],
]

topic_costs = [5, 2, 10]
```

从一个 pin 通过某个 topic 到该 topic 中任意另一个 pin，需要支付一次该 topic 的 cost。返回 `pin1` 到 `pin2` 的 minimum total cost：

```text
p1 → topic 0 → p3：cost 5
p3 → topic 1 → p4：再加 2
p4 → topic 2 → p6：再加 10
总 cost：17
```

Contract：

```text
All topic costs are nonnegative.
Same existing pin returns 0.
Missing or unreachable returns -1.
```

### 为什么普通 BFS 不再正确

BFS 最小化的是 edge/layer 数，不是权重之和。一个两层但 cost 很高的路径，可能比三层低 cost 路径更差。

### 为什么使用 Dijkstra

- 所有 weights 非负。
- 需要 minimum total cost。
- Min-heap 总是先扩展当前已知 total cost 最小的 state。

### Weighted representation

继续复用 bipartite representation：

```text
pin → topic：cost = topic_cost
topic → pin：cost = 0
```

这样进入一个 topic 时只支付一次 cost。

### Dijkstra traversal state

```text
heap entry：(total_cost, node_type, node_id)
best_pin[pin]：到 pin 的当前最小 cost
best_topic[topic]：到 topic 的当前最小 cost
```

Invariant：

```text
When a state is popped with cost equal to its recorded best cost,
that cost is final under nonnegative weights.
```

### Dijkstra 参考代码

```python
import heapq


def min_weighted_cost(index, topic_costs, pin1, pin2):
    if len(topic_costs) != len(index.topic_to_pins):
        raise ValueError("topic_costs must align with topics")
    if any(cost < 0 for cost in topic_costs):
        raise ValueError("Dijkstra requires nonnegative costs")
    if pin1 not in index.pin_to_topics or pin2 not in index.pin_to_topics:
        return -1
    if pin1 == pin2:
        return 0

    # kind is "pin" or "topic".
    heap = [(0, "pin", pin1)]
    best_pin = {pin1: 0}
    best_topic = {}

    while heap:
        cost, kind, node = heapq.heappop(heap)

        if kind == "pin":
            if cost != best_pin.get(node):
                continue  # Stale heap entry.
            if node == pin2:
                return cost

            for topic_id in index.pin_to_topics[node]:
                next_cost = cost + topic_costs[topic_id]
                if next_cost < best_topic.get(topic_id, float("inf")):
                    best_topic[topic_id] = next_cost
                    heapq.heappush(heap, (next_cost, "topic", topic_id))

        else:
            if cost != best_topic.get(node):
                continue

            for pin in index.topic_to_pins[node]:
                if cost < best_pin.get(pin, float("inf")):
                    best_pin[pin] = cost
                    heapq.heappush(heap, (cost, "pin", pin))

    return -1
```

### Weighted example

```python
weighted_topics = [
    ["p1", "p2", "p3"],
    ["p3", "p4"],
    ["p4", "p6"],
]

weighted_index = PinTopicIndex(weighted_topics)
assert min_weighted_cost(
    weighted_index,
    [5, 2, 10],
    "p1",
    "p6",
) == 17
```

### Dijkstra complexity

将 bipartite graph 看作：

```text
V = P+T nodes
O(M) bipartite edges in each direction
```

使用 binary heap：

```text
Time：O((P+T+M) log(P+T))
Space：O(P+T+M)，包含 stored representation
Query auxiliary：O(P+T)
```

### Algorithm selection extension

```text
所有 weights = 1        → BFS
weights ∈ {0,1}         → 0–1 BFS
非负 arbitrary weights → Dijkstra
存在负 weights          → Dijkstra 不适用；需要重新讨论模型与算法
```

## 8.2 Follow-up：返回实际 pin path

新增：

```python
parent[child_pin] = previous_pin
```

第一次发现 target 后，从 target 沿 parent 回溯到 source，再 reverse。

如果需要返回 topics sequence，Part III parent state 应同时记录：

```python
parent_pin[child_pin] = (previous_pin, topic_id_used)
```

## 8.3 Follow-up：大量 repeated shortest-distance queries

先问：

- graph 是否静态？
- query 数 `Q` 多大？
- 是否集中在少数 source pins？

候选：

```text
每次 BFS：无额外 cache，单 query O(P+T+M)
按 source cache distance map：适合 source 高度重复
all-pairs preprocessing：通常 space/time 太大
bidirectional BFS：单对查询可能减少实际 frontier，但 worst-case 不变
```

## 8.4 Follow-up：动态添加或删除 topics

添加 topic：

```text
append normalized topic_to_pins
for pin in topic: pin_to_topics[pin].add(topic_id)
```

删除 topic：需要同时更新 forward source of truth 与 reverse index。若频繁删除，应使用 sets、active flags 或 lazy deletion，并明确 stale-index invariant。

DSU 支持 union/additions，但不擅长 deletions；这是选择 DSU 前必须询问 update pattern 的原因。

## 8.5 Follow-up：direct relation 高频查询

如果频繁判断两个 pins 是否直接共享 topic：

```text
检查 pin_to_topics[p1] 与 pin_to_topics[p2] 是否有交集
```

可以遍历较小 set：

```text
Expected time：O(min(deg(p1), deg(p2)))
```

无需构建完整 Pin–Pin clique。

---

# 9. 最终一页速记

```text
Part I explicit graph:
    graph[pin] = set(neighbor pins)
    build O(S + ΣK_i²), space O(P+E)

Connectivity:
    DFS/BFS O(P+E), aux O(P)
    DSU for many connectivity-only queries

Part II minimum unweighted layers:
    BFS
    queue + seen + level
    seen at enqueue time

Part III large scale:
    keep topic→pins
    add pin→topics reverse index
    implicit pin→topic→pin BFS
    seen_pins + seen_topics
    preprocess O(T+S)
    query O(P+T+M)
    storage O(P+T+M)

Weighted follow-up:
    nonnegative topic costs
    bipartite Dijkstra
    heap + best_pin + best_topic
```

最后的口头决策模板：

> I’ll first define what a node, an edge, and one unit of distance mean. Then I’ll identify the dominant operations and scale. For a small graph I can materialize Pin–Pin adjacency, but at large scale each topic creates a clique, so I would preserve topic-to-pins and add a reverse pin-to-topics index. That lets me traverse the bipartite structure implicitly, process each pin and topic at most once, and avoid quadratic pair generation.
