#Part II 排序规则：

#engagement count descending
#count 相同，query lexicographically ascending

#count > 0
#k <= 0 -> []
#k > number of matches -> return all matches
#queries contain lowercase letters + spaces
#counts only increase
#top_k is a frequent query
#repeated add_query(q, delta) increments by delta

class TrieNode:
    def __init__(self):
        self.children = {}
        self.is_end = False
        self.count = 0
        
class solution:
    def __init__(self):
        self.root = TrieNode()
    
    def add_query(self, query: str, count: int) -> None:
        if not isinstance(query, str) or query=="":
            return
        if not isinstance(count, int) or isinstance(count, bool) or count <= 0:
            raise ValueError

        node = self.root
        for ch in query: # O(L), L (new nodes) additional persistent space, worst case
            if ch not in node.children:
                node.children[ch] = TrieNode()
            node = node.children[ch]
        node.count += count # O(1)
        node.is_end = True

    def top_k(self, prefix: str, k: int) -> list[str]: #time O(P+T+MlogM), space O(M+D+k)
        if not isinstance(prefix, str) or not isinstance(k, int) or isinstance(k, bool):
            raise ValueError
        if k <= 0: return []

        node = self.root
        for ch in prefix: # time O(P), extra space O(1) each time, space O(P) at worst
            if ch not in node.children:
                node.children[ch] = TrieNode()
            node = node.children[ch]

        ans = []
        def dfs(curr, path): # time O(T). T trie nodes. O(M+D) space
            if curr.is_end:
                ans.append((path, curr.count))
            for ch, child in curr.children.items(): # curr.children.items() 得到的是 (key, value) pair。
                dfs(child, path+ch) # string coping cost: `path+ch`, O(T)
        
        dfs(node, prefix)
        ans.sort(key = lambda x: (-x[1], x[0])) # count desc, letter asc
        return [query for query, _ in ans[:k]] # sorting: O(MlogM) time, O(k) space


engine = solution()

engine.add_query("cat", 20)
engine.add_query("cat furniture", 50)
engine.add_query("cat tree", 50)
engine.add_query("catering ideas", 10)
engine.add_query("dog", 100)

assert engine.top_k("cat", 3) == ["cat furniture", "cat tree", "cat"]

# duplicate means increment
engine.add_query("cat", 40)

assert engine.top_k("cat", 3) == [
    "cat",
    "cat furniture",
    "cat tree"
]

# k larger than result count
assert engine.top_k("dog", 10) == ["dog"]

# no match
assert engine.top_k("z", 3) == []

# k <= 0
assert engine.top_k("cat", 0) == []

# empty prefix = global top-k
assert engine.top_k("", 2) == [
    "dog",
    "cat",
]