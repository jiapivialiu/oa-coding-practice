#Part III：Large-Scale Requirement
#现在数据规模发生变化：
#T：最多 100,000 个 topics
#P = unique pins 数量
#M：ΣKᵢ，总 Pin–Topic memberships 最多 1,000,000
# Kᵢ = topic i 的 unique pins 数

#某个 topic 可能包含 100,000 个 pins. Part I 的 Pin–Pin graph 会为一个大 topic 创建：
# (100000 chooses 2)条 pin-pin edges，无法接受。

# constraints:
# 不允许显式创建 O(ΣKᵢ²) 个 Pin–Pin edges
# 目标空间必须与 M 近似线性


# 1. 当前 pin-pin representation 为什么不能扩展到这个规模？
# the time complexity if sum_i K_i^2, which is on a 10^10 scale, which is too large
# 给出 worst-case time is O(sum_i K_i^2 + sum L_i), worst case space is O(P+E)
# followup: 核心 operations 是什么？从一个 pin 找什么？从一个 topic 找什么？

# 2. 列出至少两种新 representation，并比较 operations 和 time/space trade-offs。
# add index onto current graph: topic index as key, and unique pins as value (set). time O() and space O()
# use bipartite graph instead: 


# 3. 选择 extend 当前 representation by adding an index or replace representation；reason.
# topics representation by adding an index. because: 


# 4. 定义新的 traversal state 和 invariants。
# queue entry 表示什么: a pin
# 需要哪些 seen sets: pin, topic
# BFS 的“一层”对应什么: pin-topic-pin
# 最重要的 invariant:
#At the beginning of each outer BFS iteration, all pins currently in the queue have the same minimum topic-layer distance.
#Expanding a pin at distance d through an unseen topic discovers pins at distance d + 1.
#Each pin is enqueued at most once, and each topic is expanded at most once.

# 5. 定义 traversal state：
# queue entry 表示什么；
# 需要哪些 seen sets；
# BFS 的“一层”对应什么；
# 最重要的 invariant。

# 6. 给出 preprocessing time、query time、space，必须用 T/P/M 表示。
#T = topics
#P = unique pins
#M = unique Pin–Topic memberships
#S = ΣLᵢ，包含 topic 内重复项的原始输入长度

# build graph: O(S) in time, O(P+M) in space
# bfs: O(T+M+P) in time, O(P+T) in space
# total: O(S) in time, O(P+M+T) in space

# 6. 完整代码和测试: 
from collections import defaultdict, deque
def build_pin_to_topics(topics):
    """
    Return the Pin-Topic graph.
    """
    pin_topic = defaultdict(set)
    for i in range(len(topics)):
        unique_pins = list(set(topics[i]))
        for pin in unique_pins:
            pin_topic[pin].add(i)

    return pin_topic

def min_topic_layers_large(topics, graph, pin1, pin2):
    """
    Return the same minimum topic-layer distance as Part II,
    but do not explicitly construct all pairwise Pin-Pin edges.

    Same existing pin: 0
    Directly share a topic: 1
    Missing or unreachable: -1
    """
    if pin1 not in graph or pin2 not in graph:
        return -1
    if pin1 == pin2:
        return 0

    q = deque()
    q.append(pin1)
    ans = 0
    seen_topic = set()
    seen_pin = {pin1}
    while q:
        n = len(q)
        ans += 1
        for _ in range(n):
            from_pin = q.popleft()
            for topic in graph[from_pin]:
                if topic in seen_topic:
                    continue
                seen_topic.add(topic)
                for to_pin in topics[topic]:
                    if to_pin in seen_pin:
                        continue
                    if to_pin == pin2:
                        return ans
                    seen_pin.add(to_pin)
                    q.append(to_pin)
                
    return -1
                

topics = [
    ["p1", "p2", "p3"],
    ["p3", "p4"],
    ["p4", "p6"],
    ["p5"],
]
graph = build_pin_to_topics(topics)
assert min_topic_layers_large(topics, graph, "p1", "p2") == 1
assert min_topic_layers_large(topics, graph, "p1", "p4") == 2
assert min_topic_layers_large(topics, graph, "p1", "p6") == 3
assert min_topic_layers_large(topics, graph, "p1", "p1") == 0
assert min_topic_layers_large(topics, graph, "p1", "p5") == -1
assert min_topic_layers_large(topics, graph, "missing", "p1") == -1

# One huge topic: direct distance must remain 1
large_topic = [[f"p{i}" for i in range(10_000)]]
large_graph = build_pin_to_topics(large_topic)
assert min_topic_layers_large(large_topic, large_graph, "p1", "p2") == 1
assert min_topic_layers_large(large_topic, large_graph, "p1", "p4") == 1
assert min_topic_layers_large(large_topic, large_graph, "p1", "p6") == 1
assert min_topic_layers_large(large_topic, large_graph, "p1", "p1") == 0
assert min_topic_layers_large(large_topic, large_graph, "p1", "p9999") == 1
assert min_topic_layers_large(large_topic, large_graph, "missing", "p1") == -1


# Duplicate pins inside a topic
duplicate_topics = [["a", "a", "b"], ["b", "c"]]
dedup_graph = build_pin_to_topics(duplicate_topics)
assert min_topic_layers_large(duplicate_topics, dedup_graph, "a", "b") == 1
assert min_topic_layers_large(duplicate_topics, dedup_graph, "a", "c") == 2
assert min_topic_layers_large(duplicate_topics, dedup_graph, "a", "d") == -1
assert min_topic_layers_large(duplicate_topics, dedup_graph, "a", "a") == 0
assert min_topic_layers_large(duplicate_topics, dedup_graph, "b", "c") == 1
assert min_topic_layers_large(duplicate_topics, dedup_graph, "missing", "a") == -1


# Cycle and unreachable component
cycle_topics = [
    ["a", "b"],
    ["b", "c"],
    ["c", "a"],
    ["z"],
]
cycle_graph = build_pin_to_topics(cycle_topics)
assert min_topic_layers_large(cycle_topics, cycle_graph, "a", "a") == 0
assert min_topic_layers_large(cycle_topics, cycle_graph, "a", "c") == 1
assert min_topic_layers_large(cycle_topics, cycle_graph, "a", "b") == 1
assert min_topic_layers_large(cycle_topics, cycle_graph, "a", "d") == -1
assert min_topic_layers_large(cycle_topics, cycle_graph, "b", "c") == 1
assert min_topic_layers_large(cycle_topics, cycle_graph, "missing", "a") == -1
