from collections import defaultdict

#T   = topic 数量
#P   = unique pin 数量
#K_i = 第 i 个 topic 中 unique pins 数量
#Kmax = max K_i
#E   = 最终 Pin–Pin graph 的不同无向边数
#   一个包含 K_i 个 pins 的 topic，需要创建：(K_i chooses 2)=O(K_i^2) 条candidate edges。
# For topic i: L_i is the total length, K_i is the unique pins

# build graph 
# total time = O(sum_i L_i + sum_i K_i^2), L cannot be omitted, since there can be a million replicates
# total space = O(P+E+Kmax) = O(P+E)
# auxiliary (deduplicate): O(sum_i L_i) in time, O(Kmax) in space (注意是max, 不是sum)
# build graph: O(sum_i K_i^2) in time, O(P+E) in space

# bfs
# time = O(P+E) in worst case
# space = O(P) in worst case
    
# build graph + bfs
# total time: O(sum_i L_i + sum_i K_i^2), where sum_i L_i>= P, sum_i K_i^2 >= E
# total space: O(P+E)

def build_pin_graph(topics):
    """
    Return the Pin-Pin graph.
    """
    pin_pin = defaultdict(set)
    for topic in topics:
        unique_pins = list(set(topic))
        
        e = len(unique_pins)
        for i in range(e):
            pin1 = unique_pins[i]
            pin_pin[pin1] # = pin_pin.get(pin1, set()) # the second part can be dropped
            for j in range(i+1, e): # upper triangle
                pin2 = unique_pins[j]
                pin_pin[pin1].add(pin2)
                pin_pin[pin2].add(pin1)
    return pin_pin


# BFS version
from collections import deque
def are_related(graph, pin1, pin2):
    """
    Return whether pin1 can reach pin2 through zero or more Pin-Pin edges.
    """
    if pin1 not in graph or pin2 not in graph:
        return False
    if pin1 == pin2:
        return True
    q = deque() # O(P)
    q.append(pin1)
    seen = set() # O(P)
    seen.add(pin1) 
    while q:
        pin = q.popleft() # time: visit all nodes in worst case
        for new_pin in graph.get(pin, set()): # time: visit all edges in worst case
            if new_pin == pin2:
                return True
            if new_pin in seen:
                continue
            seen.add(new_pin)
            q.append(new_pin)
    return False

topics = [ ["p1", "p2", "p3"], ["p3", "p4"], ["p5"], ]
graph = build_pin_graph(topics)

# tests:
#multi-hop
#unreachable
#same pin
#empty input
#single-pin topic
#duplicate within topic
#repeated edge across topics
#cycle
assert are_related(graph, "p1", "p4") is True
assert are_related(graph, "p1", "p5") is False
assert are_related(graph, "p1", "p1") is True
assert are_related(graph, "p6", "p6") is False

topics = [["p5"]]
graph = build_pin_graph(topics)
assert 'p5' in graph
assert graph['p5'] == set()
assert are_related(graph, "p5", "p1") is False
assert are_related(graph, "p5", "p5") is True

topics = [["p6", "p5", "p1", "p5"], ["p5", "p4"], ["p2", "p6"], ["p2", "p4"]]
graph = build_pin_graph(topics)
assert are_related(graph, "p4", "p1") is True

# cycle
topics = [['p1', 'p2'], ['p2', 'p3'], ['p3', 'p1'], ['p4']]
graph = build_pin_graph(topics)
assert are_related(graph, 'p1', 'p3') is True
assert are_related(graph, 'p1', 'p4') is False

# structural assertion:
topics = []
graph = build_pin_graph(topics)
assert len(graph) == 0
assert are_related(graph, 'p1', 'p1') is False

# deduplicate graph
topics = [['a', 'a', 'b'], ['a', 'b']]
graph = build_pin_graph(topics)
assert graph['a'] == {"b"}
assert graph['b'] == set(['a'])



# DSU solution
class DSU:
    def __init__(self):
        self.parent = {}
        self.size = {}

    def add(self, x):
        if x not in self.parent:
            self.parent[x] = x
            self.size[x] = 1

    def find(self, x):
        # Path compression
        if self.parent[x] != x:
            self.parent[x] = self.find(self.parent[x])
        return self.parent[x]

    def union(self, a, b):
        self.add(a)
        self.add(b)

        root_a = self.find(a)
        root_b = self.find(b)

        if root_a == root_b:
            return

        # Union by size
        if self.size[root_a] < self.size[root_b]:
            root_a, root_b = root_b, root_a

        self.parent[root_b] = root_a
        self.size[root_a] += self.size[root_b]

    def connected(self, a, b):
        if a not in self.parent or b not in self.parent:
            return False

        return self.find(a) == self.find(b)

def build_pin_dsu(topics):
    dsu = DSU()

    for topic in topics:
        unique_pins = list(set(topic))

        if not unique_pins:
            continue

        first = unique_pins[0]
        dsu.add(first)

        for pin in unique_pins[1:]:
            dsu.union(first, pin)

    return dsu    
dsu = build_pin_dsu([
    ["p1", "p2", "p3"],
    ["p3", "p4"],
    ["p5"],
])

assert dsu.connected("p1", "p4") is True
assert dsu.connected("p1", "p5") is False
assert dsu.connected("p5", "p5") is True
assert dsu.connected("missing", "missing") is False
