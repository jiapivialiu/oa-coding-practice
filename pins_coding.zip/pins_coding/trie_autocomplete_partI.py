

# example
queries = [
    "cat",
    "cat furniture",
    "cat tree",
    "catering ideas",
    "dog",
    "dog bed",
]

#字符串：
#case-sensitive
#可以包含 lowercase letters 和 spaces
#duplicate query 不会作为两个独立 query 存储




# part I Prefix Search
#class PinterestAutocomplete:
#    add_query(query: str) -> None 动态加入一个新的历史 query。
#    search(prefix: str) -> list[str] 返回所有以 prefix 开头的 query，按 lexicographical order 返回。

# Part I 
# 不要立刻假设 Trie。
# 先问: 
# query 数量 N 大概多少？
# 最大 string length L？
# add 和 search 哪个更频繁？
# 是否需要返回所有结果？
# empty prefix 怎么定义？
# empty query 是否允许？
# 
# 然后选择 representation。



# prefix solution: repeatedly save shared nodes
# N: # queries
# L: average single query length; L_m: worst
# P: prefix length
# 
from collections import defaultdict
class PinterestAutocomplete: 
    def __init__(self):
        self.prefix_to_queries = defaultdict(set) 
    
    def add_query(self, query): # n = len(query), quadratic in space, linear in time
        for i in range(len(query)+1): # space of query[:i] for i=0,...,n is 1+...+n=O(n^2) with O(n) repeated reprefences
            # N=10 Million queries with L=30 average length = 3*10Million=3*10^8 references --> large overhead
            self.prefix_to_queries[query[:i]].add(query) # space O(N*n), for each query O(n), 

    def search(self, prefix): # space O(1)
        # K: at most K queries returned
        # M: average length of each query
        return sorted(self.prefix_to_queries.get(prefix, set())) # get: O(1) time, sort: O(K log K) time, O(KlogK * M) at worst
        # sorted: auxiliary space O(K)


# The inverted index duplicates each query across all of its prefixes, 
# while a Trie stores each shared prefix path once and only branches when queries diverge.
class TrieNode:
    def __init__(self):
        self.children = {}
        self.is_end = False
    
class triesolution:
    def __init__(self):
        self.root = TrieNode()
    
    def add_query(self, query):
        if not isinstance(query, str) or query == "":
            raise ValueError
        
        node = self.root
        for ch in query: # len(query) = L
            if ch not in node.children:
                node.children[ch] = TrieNode() # O(1) insert, O(L) time&space at worst
            node = node.children[ch]
        
        node.is_end = True
    
    def search(self, prefix): # len(prefix) = P
        if not isinstance(prefix, str):
            raise ValueError
        
        node = self.root
        for ch in prefix: # early stopping
            if ch not in node.children:
                return []
            node = node.children[ch]
        
        ans = []
        def dfs(curr, path):
            if curr.is_end:
                ans.append(path)
            for ch in sorted(curr.children):
                dfs(curr.children[ch], path+ch)
            
        dfs(node, prefix)
        return ans
    
        
# test:
engine = triesolution()
print(engine.add_query("cat"))
print(engine.add_query("cat tree"))
print(engine.add_query("catering ideas"))
print(engine.add_query("dog"))

print(engine.search("cat"))
#[
#    "cat",
#    "cat tree",
#    "catering ideas"
#]
print(engine.search("")) # return all queries
print(engine.search("a"))
